// No `host`, no `key`: the remote-extension mode (pairing this extension with a host on another
// machine over an encrypted bridge) was removed in S43 — the bridge is loopback plaintext only.
// Stale `host`/`key` values persisted by older versions are simply ignored by the spread below.
const DEFAULTS = { port: 47362, token: '', tokenOn: false, forceTeleport: false, inDemandRetry: true, rateLimit: true };
const area = () => (globalThis.chrome && chrome.storage && chrome.storage.local);

export async function getSettings() {
  const a = area(); if (!a) return { ...DEFAULTS };
  const v = await a.get('settings'); return { ...DEFAULTS, ...(v.settings || {}) };
}
export async function setSettings(patch) {
  const a = area(); if (!a) return; const cur = await getSettings();
  await a.set({ settings: { ...cur, ...patch } });
}
// (The old locally-stored search-list API was removed: searches are pushed by the host via the
// PTBP `config` message — see background.js applyConfig — and never persisted in the extension.)
