// PTBP client for the POEFixer Trade Bridge. Matches host spec §8.
//
// LOOPBACK PLAINTEXT ONLY (S43, 2026-08-05). The keyed/encrypted client mode — the chello/cserver
// PSK handshake and sealed envelopes that let this extension pair with a host on ANOTHER machine —
// was REMOVED together with the host's keyed listener: the remote-extension feature is gone (the
// remote AGENT, a separate program with its own transport, replaced it). This client connects to
// 127.0.0.1 and speaks plaintext PTBP frames, byte-identical to the historical no-key path.
import { buildTimingPong as timingPongPayload } from './timing.js';

export function buildHello(client, token, version, session) {
  const m = { type: 'hello', proto: 1, client };
  if (version) m.version = version;
  if (token) m.token = token;
  if (session) m.session = session;
  return JSON.stringify(m);
}
export function buildBuyRequest(id, seq, group, prepareId = '') {
  const wireGroup = { ...(group || {}) };
  const m = { type: 'buy_request', id, seq };
  if (prepareId) m.prepareId = prepareId;
  m.group = wireGroup;
  if (wireGroup.timing) {
    m.timing = wireGroup.timing;
    delete wireGroup.timing;
  }
  return JSON.stringify(m);
}
export function buildBatchPrepare(id, seq, group, origin) {
  const wireGroup = { ...(group || {}) };
  const items = Array.isArray(wireGroup.items) ? wireGroup.items : [];
  const maxItems = origin === 'live' ? 5 : (origin === 'manual' ? 100 : 0);
  if (!id || !seq || items.length < 1 || items.length > maxItems) {
    throw new Error('batch_prepare item count is outside the origin limit');
  }
  const m = { type: 'batch_prepare', id, seq, origin, group: wireGroup };
  if (wireGroup.timing) {
    m.timing = wireGroup.timing;
    delete wireGroup.timing;
  }
  return JSON.stringify(m);
}
export function buildBatchCancel(id, seq, reason) {
  return JSON.stringify({ type: 'batch_cancel', id, seq, reason });
}
export function buildTradeEvent(seq, ev) {
  const m = { type: 'trade_event', seq, stage: ev.stage, outcome: ev.outcome, itemId: ev.itemId || '', detail: ev.detail || '' };
  if (ev.item) m.item = ev.item;
  if (ev.timing) m.timing = ev.timing;
  return JSON.stringify(m);
}
export function buildAck(ackSeq) { return JSON.stringify({ type: 'ack', ackSeq }); }
export function buildTimingPong(ping, receivedAtUnixMs, sentAtUnixMs) {
  return JSON.stringify(timingPongPayload(ping, receivedAtUnixMs, sentAtUnixMs));
}

function newLogicalSession() {
  const bytes = new Uint8Array(16);
  if (globalThis.crypto && typeof globalThis.crypto.getRandomValues === 'function') {
    globalThis.crypto.getRandomValues(bytes);
  } else {
    for (let i = 0; i < bytes.length; i++) bytes[i] = Math.floor(Math.random() * 256);
  }
  return [...bytes].map(x => x.toString(16).padStart(2, '0')).join('');
}

export class PtbpClient {
  constructor(opts) {
    this.opts = opts;
    this.session = typeof opts.session === 'string' &&
      /^[A-Za-z0-9_-]{8,64}$/.test(opts.session)
      ? opts.session : newLogicalSession();
    this.ws = null;
    this.seq = 0;
    this.idCounter = 0;
    this.prepareCounter = 0;
    this.pending = new Map();        // seq -> tracked producer frame, replayed verbatim until ACK
    this.prepareWaiters = new Map(); // prepare id -> {seq, resolve, reject, timer}
    this.prepareSeqs = new Map();    // prepare id -> seq; survives waiter rejection for orphan cleanup
    this.abandonedPrepares = new Set(); // rejected waiter ids; replayed ready must cancel these only
    this.connected = false;
    this.lastStatus = { ready: false };
    this._reconnectMs = 1000;
    this._reconnectTimer = null;
    this._closedByUser = false;
  }
  connect() {
    this._closedByUser = false;
    // INVARIANT: at most ONE socket may be CONNECTING/OPEN at a time. Without this, a single extension
    // can open a SECOND WebSocket (the keepalive alarm in background.js calling connect() in parallel
    // with a scheduled reconnect after a host restart gap). The host bridge is single-client and kicks
    // the older connection on every new accept; the kicked side auto-reconnects → the two sockets
    // ping-pong-kick each other forever (~1/s), spamming reconnects, faking an "outdated extension"
    // version read, and inflating the trade-site request rate into a 429 ban. Keep the live one.
    if (this.ws && (this.ws.readyState === 0 /* CONNECTING */ || this.ws.readyState === 1 /* OPEN */)) return;
    if (this.ws) { try { this.ws.onopen = this.ws.onmessage = this.ws.onerror = this.ws.onclose = null; this.ws.close(); } catch {} this.ws = null; }
    const WS = (typeof WebSocket !== 'undefined') ? WebSocket : null;
    if (!WS) { this.opts.onError && this.opts.onError({ code: 'no_websocket' }); return; }
    let ws;
    try { ws = new WS(this.opts.url); } catch (e) { this._scheduleReconnect(); return; }
    this.ws = ws;
    ws.onopen = () => {
      this.connected = true; this._reconnectMs = 1000;
      if (this._reconnectTimer) { clearTimeout(this._reconnectTimer); this._reconnectTimer = null; }
      ws.send(buildHello(this.opts.client || 'PoeFixerExt/1.0', this.opts.token || '',
        this.opts.version || '', this.session));
      // resend un-ACKed frames (ordered by seq)
      [...this.pending.entries()].sort((a, b) => a[0] - b[0]).forEach(([, f]) => ws.send(f));
      this.opts.onOpen && this.opts.onOpen();
    };
    ws.onmessage = (ev) => {
      const data = typeof ev.data === 'string' ? ev.data : String(ev.data);
      this._onMessage(data);
    };
    ws.onerror = () => { /* onclose follows */ };
    ws.onclose = () => {
      if (this.ws !== ws) return;       // a superseded socket fired late — ignore it
      this.ws = null; this.connected = false;
      this._rejectPrepareWaiters('disconnected');
      this.opts.onClose && this.opts.onClose();
      if (!this._closedByUser) this._scheduleReconnect();
    };
  }
  close() {
    this._closedByUser = true;
    if (this._reconnectTimer) { clearTimeout(this._reconnectTimer); this._reconnectTimer = null; }
    if (this.ws) try { this.ws.close(); } catch {}
    this._rejectPrepareWaiters('closed');
  }
  _scheduleReconnect() {
    if (this._closedByUser || this._reconnectTimer) return;   // one pending reconnect at a time
    const ms = this._reconnectMs; this._reconnectMs = Math.min(this._reconnectMs * 2, 15000);
    this._reconnectTimer = setTimeout(() => { this._reconnectTimer = null; if (!this._closedByUser) this.connect(); }, ms);
  }
  get ready() { return this.connected && !!this.lastStatus.ready; }
  _send(frame) {
    if (!this.ws || !this.connected) return false;
    try { this.ws.send(frame); return true; } catch {}
    return false;
  }
  // Track an un-ACKed frame for reconnect replay. Capped so a connected host that never ACKs
  // (or a very long host outage) cannot grow the map unbounded; the oldest frames drop first.
  _trackPending(seq, frame) {
    this.pending.set(seq, frame);
    while (this.pending.size > 500) this.pending.delete(this.pending.keys().next().value);
  }
  sendBuyRequest(group, prepareId = '') {
    if (prepareId) {
      const prepareSeq = this.prepareSeqs.get(prepareId);
      if (prepareSeq) this.pending.delete(prepareSeq);
      this.prepareSeqs.delete(prepareId);
      this.abandonedPrepares.delete(prepareId);
    }
    const id = `r-${this.session}-${++this.idCounter}-${this.seq + 1}`;
    const seq = ++this.seq;
    const frame = buildBuyRequest(id, seq, group, prepareId);
    this._trackPending(seq, frame);
    this._send(frame);
    return id;
  }
  prepareBuy(group, origin = 'live') {
    if (!this.connected) return Promise.reject(Object.assign(
      new Error('PTBP is disconnected'), { code: 'disconnected' }));
    const id = `p-${this.session}-${++this.prepareCounter}-${this.seq + 1}`;
    const seq = ++this.seq;
    const frame = buildBatchPrepare(id, seq, group, origin);
    this._trackPending(seq, frame);
    return new Promise((resolve, reject) => {
      const timeoutMs = Math.max(1, Number(this.opts.prepareTimeoutMs) || 5000);
      const timer = setTimeout(() => {
        const waiter = this.prepareWaiters.get(id);
        if (!waiter) return;
        this.prepareWaiters.delete(id);
        this.pending.delete(seq);
        this.cancelPrepared(id, 'prepare_timeout');
        reject(Object.assign(new Error('packet batch prepare timed out'), { code: 'timeout' }));
      }, timeoutMs);
      this.prepareWaiters.set(id, { seq, resolve, reject, timer });
      this.prepareSeqs.set(id, seq);
      if (!this._send(frame)) {
        clearTimeout(timer);
        this.prepareWaiters.delete(id);
        this.prepareSeqs.delete(id);
        this.pending.delete(seq);
        reject(Object.assign(new Error('PTBP is disconnected'), { code: 'disconnected' }));
      }
    });
  }
  cancelPrepared(id, reason = 'cancelled') {
    const waiter = this.prepareWaiters.get(id);
    if (waiter) {
      clearTimeout(waiter.timer);
      this.prepareWaiters.delete(id);
      this.pending.delete(waiter.seq);
      waiter.reject(Object.assign(new Error(reason), { code: 'cancelled' }));
    }
    const prepareSeq = this.prepareSeqs.get(id);
    if (prepareSeq) this.pending.delete(prepareSeq);
    this.prepareSeqs.delete(id);
    this.abandonedPrepares.delete(id);
    const seq = ++this.seq;
    const frame = buildBatchCancel(id, seq, reason);
    this._trackPending(seq, frame);
    this._send(frame);
    return id;
  }
  _rejectPrepareWaiters(code) {
    for (const [id, waiter] of this.prepareWaiters) {
      clearTimeout(waiter.timer);
      waiter.reject(Object.assign(new Error(code), { code }));
      this.prepareWaiters.delete(id);
      this.abandonedPrepares.add(id);
    }
  }
  sendTradeEvent(ev) {
    const seq = ++this.seq;
    const frame = buildTradeEvent(seq, ev);
    this._trackPending(seq, frame);
    this._send(frame);
  }
  // Best-effort log forwarding to POEFixer (not seq/ack tracked).
  sendLog(level, message) { this._send(JSON.stringify({ type: 'log', level, message })); }
  // Report a search's live-WS state back to POEFixer (drives the Trade Link "Connecting/Live" UI).
  sendSearchStatus(searchId, state) { this._send(JSON.stringify({ type: 'search_status', searchId, state })); }
  // Manual-buy lifecycle/progress back to POEFixer (seq/ACK tracked + redelivered on reconnect).
  sendManualBuyStatus(id, state, counts) {
    const seq = ++this.seq;
    const c = counts || {};
    const frame = JSON.stringify({ type: 'manual_buy_status', id, seq, state,
      processed: c.processed | 0, bought: c.bought | 0, failed: c.failed | 0,
      unknown: c.unknown | 0, skipped: c.skipped | 0,
      total: c.total | 0, detail: c.detail || '' });
    this._trackPending(seq, frame);
    this._send(frame);
  }
  _onMessage(text) {
    let m; try { m = JSON.parse(text); } catch { return; }
    this._dispatch(m);
  }
  _dispatch(m) {
    switch (m.type) {
      case 'welcome': this.lastStatus.ready = !!m.ready; this.opts.onWelcome && this.opts.onWelcome(m); break;
      case 'status': this.lastStatus = m; this.opts.onStatus && this.opts.onStatus(m); break;
      case 'config': this.opts.onConfig && this.opts.onConfig(m); break;
      case 'ack': for (const k of [...this.pending.keys()]) if (k <= m.ackSeq) this.pending.delete(k); break;
      case 'buy_progress': this.opts.onBuyProgress && this.opts.onBuyProgress(m); break;
      case 'batch_ready': {
        this._send(buildAck(m.seq));
        const waiter = this.prepareWaiters.get(m.id);
        if (waiter) {
          clearTimeout(waiter.timer);
          this.prepareWaiters.delete(m.id);
          this.pending.delete(waiter.seq);
          this.prepareSeqs.delete(m.id);
          this.abandonedPrepares.delete(m.id);
          waiter.resolve({ id: m.id, expiresInMs: m.expiresInMs });
        } else if (this.abandonedPrepares.has(m.id)) {
          // A disconnect rejected the only caller but deliberately retained the tracked
          // prepare for replay. If the replay arms the host, nobody can ever bind it to a
          // buy_request, so cancel it explicitly instead of leaving a hidden live batch.
          this.abandonedPrepares.delete(m.id);
          this.cancelPrepared(m.id, 'prepare_abandoned');
        }
        break;
      }
      case 'buy_result': this._send(buildAck(m.seq)); this.opts.onBuyResult && this.opts.onBuyResult(m); break;
      case 'manual_buy': this._send(buildAck(m.seq)); this.opts.onManualBuy && this.opts.onManualBuy(m); break;
      case 'manual_buy_cancel': this._send(buildAck(m.seq)); this.opts.onManualBuyCancel && this.opts.onManualBuyCancel(m); break;
      case 'timing_ping': {
        const received = Date.now();
        this._send(buildTimingPong(m, received, Date.now()));
        break;
      }
      case 'error': {
        const waiter = this.prepareWaiters.get(m.id);
        if (waiter) {
          clearTimeout(waiter.timer);
          this.prepareWaiters.delete(m.id);
          this.pending.delete(waiter.seq);
          waiter.reject(Object.assign(new Error(m.code || 'prepare_failed'), { code: m.code || 'prepare_failed' }));
        }
        const prepareSeq = this.prepareSeqs.get(m.id);
        if (prepareSeq) this.pending.delete(prepareSeq);
        this.prepareSeqs.delete(m.id);
        this.abandonedPrepares.delete(m.id);
        this.opts.onError && this.opts.onError(m);
        break;
      }
      default: break;
    }
  }
}
