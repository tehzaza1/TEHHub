// Trade-site logic for the POEFixer Trade Bridge. Pure helpers + fetch/whisper wrappers.
//
// UNIFIED: this ONE extension drives BOTH POE1Fixer and POE2Fixer. The host pushes each search's
// `realm` over the local PTBP channel; it is the single API discriminator:
//   * POE1Fixer sends realm = "" (empty)      → PoE1 API: /api/trade/…,  /trade/search/<league>/<id>,
//     live {"new":[ids]} OR {"result":jwt}, whisper body {token[,continue]} (force-teleport).
//   * POE2Fixer sends realm = non-empty (poe2) → PoE2 API: /api/trade2/… (with a /<realm>/ segment),
//     live {"result":jwt}, whisper body {token[,continue]} (force-teleport + in-demand retry).
// Force-teleport (`continue`) is sent for BOTH games since v1.3.0 — see whisperBody. The in-demand
// RETRY also runs on BOTH games since 2026-07-31: PoE1 DOES return the {"success":false} + no-error
// shape when another buyer whispered first (field report + browser capture — the old PoE1 exclusion
// was an assumption, disproven like the rest of the "PoE1 has no teleport" family). The re-send
// carries continue:true on BOTH games (BOOLEAN — the site's own "whisper again" click, per the
// capture on the unified backend); force-teleport's continue:'true' stays a STRING. Do not merge
// the two wire shapes.
// isPoe2(realm) is that discriminator, mirrored (NOT imported) by the MAIN-world agents in
// background.js. Only ever talk to known PoE trade hosts. `domain` arrives over the local channel
// (and from parseSearchUrl), so it is validated against this allowlist before being trusted —
// without it a crafted domain could point the credentialed fetch/WS at an arbitrary host.
//
// MIRROR CONTRACT: the MAIN-world agents in background.js (pfxLiveAgent / pfxMbFetchPick /
// pfxMbWhisper) inline near-copies of the fetch/whisper/parse logic here, because
// executeScript(world:'MAIN') cannot import modules. This file is the TESTED reference
// (tests/trade.test.mjs) — when changing behavior in either place, port the change to the other.
const ALLOWED_HOSTS = new Set(['www.pathofexile.com', 'poe.game.daum.net', 'poe.kakaogames.com']);

// THE discriminator: a non-empty realm means PoE2 (/trade2); an empty realm means PoE1 (/trade).
export function isPoe2(realm) { return !!(realm && String(realm).length); }
function apiSeg(realm) { return isPoe2(realm) ? 'trade2' : 'trade'; }

export function hostFor(realm, domain) {
  // Prefer the host-pushed trade domain when it is a known PoE host; otherwise fall back to the
  // legacy realm heuristic (intl vs. the old `kr` guess).
  if (domain && ALLOWED_HOSTS.has(String(domain).toLowerCase())) return String(domain).toLowerCase();
  return (realm && String(realm).includes('kr')) ? 'poe.game.daum.net' : 'www.pathofexile.com';
}
export function parseSearchUrl(url) {
  try {
    const u = new URL(url);
    // PoE2: /trade2/search/<realm>/<league>/<id>
    const m2 = u.pathname.match(/\/trade2\/search\/([^/]+)\/([^/]+)\/([^/?#]+)/);
    if (m2) return { realm: m2[1], league: decodeURIComponent(m2[2]), searchId: m2[3], domain: u.host };
    // PoE1: /trade/search/<league>/<id> — no realm segment (realm stays empty ⇒ PoE1 routing).
    const m1 = u.pathname.match(/\/trade\/search\/([^/]+)\/([^/?#]+)/);
    if (m1) return { realm: '', league: decodeURIComponent(m1[1]), searchId: m1[2], domain: u.host };
    return null;
  } catch { return null; }
}
export function liveWsUrl({ realm, league, searchId, domain }) {
  const host = hostFor(realm, domain);
  return isPoe2(realm)
    ? `wss://${host}/api/trade2/live/${realm}/${encodeURIComponent(league)}/${searchId}`
    : `wss://${host}/api/trade/live/${encodeURIComponent(league)}/${searchId}`;
}
export function searchPageUrl({ realm, league, searchId, domain }) {
  const host = hostFor(realm, domain);
  return isPoe2(realm)
    ? `https://${host}/trade2/search/${realm}/${encodeURIComponent(league)}/${searchId}`
    : `https://${host}/trade/search/${encodeURIComponent(league)}/${searchId}`;
}
export function parseNew(json) {
  if (Array.isArray(json)) return json.filter(x => typeof x === 'string');
  if (json && Array.isArray(json.new)) return json.new.filter(x => typeof x === 'string');
  return [];
}
// The live-fetch path piece: PoE1 live can send {"new":[ids]} → comma-join the ids, capped at the
// API's 10-per-fetch limit. PoE2 (and the unified backend) send one JWT per listing — the JWT goes
// in the path where ids normally go. Mirrored (not imported) by the MAIN-world pfxLiveAgent.
export function fetchPathFor(ids) {
  return (Array.isArray(ids) ? ids : []).slice(0, 10).join(',');
}
// === 0.5.5 search ids ===
// The id is base64url(gzip(query JSON)) without padding, and the same query has several valid
// spellings (the page and the site's server mint different gzip headers). The string stays the
// key; these three only get the query back OUT of it so Manual Buy needs no GET resolve.
// MIRRORED (not imported) inside background.js's MAIN-world pfxMbFetchPick.
const COMPRESSED_ID_PREFIX = 'H4sI';            // base64 of the gzip magic 1f 8b 08
const MAX_INFLATED_QUERY_BYTES = 64 * 1024;     // a defect guard, not a policy
const MAX_SEARCH_ID_CHARS = 2048;   // the id is ASCII, so characters are bytes — the same bound as C++ kMaxIdBytes / Go MaxSearchIDBytes / node-protocol v3 trade_search_id_bytes
export function looksCompressedSearchId(id) {
  return typeof id === 'string' && id.startsWith(COMPRESSED_ID_PREFIX);
}
// Both alphabets, padding optional. null for anything that is not a base64 string.
export function searchIdBytes(id) {
  if (typeof id !== 'string') return null;
  if (id.length > MAX_SEARCH_ID_CHARS) return null;
  const s = id.replace(/=+$/, '').replace(/-/g, '+').replace(/_/g, '/');
  if (!s.length || s.length % 4 === 1 || /[^A-Za-z0-9+/]/.test(s)) return null;
  const bin = atob(s + '='.repeat((4 - (s.length % 4)) % 4));
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
// The POST-ready query object, or null. A body-shaped id ({"query":…,"sort":…}) is unwrapped.
export async function decodeSearchQuery(id) {
  try {
    if (!looksCompressedSearchId(id)) return null;
    const bytes = searchIdBytes(id);
    if (!bytes) return null;
    const reader = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip')).getReader();
    const chunks = []; let total = 0;
    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      total += value.byteLength;
      if (total > MAX_INFLATED_QUERY_BYTES) { await reader.cancel(); return null; }
      chunks.push(value);
    }
    const joined = new Uint8Array(total); let at = 0;
    for (const c of chunks) { joined.set(c, at); at += c.byteLength; }
    // fatal: a valid gzip whose payload is not UTF-8 answers null, never a query with U+FFFD in it.
    const obj = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(joined));
    if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return null;
    const q = obj.query;
    return (q && typeof q === 'object' && !Array.isArray(q)) ? q : obj;
  } catch { return null; }
}
export function fetchUrl({ realm, searchId, ids, jwt, domain }) {
  const host = hostFor(realm, domain);
  const path = jwt ? jwt : fetchPathFor(ids);   // cap ids at the API's 10-per-fetch limit (matches the live agent)
  return isPoe2(realm)
    ? `https://${host}/api/trade2/fetch/${path}?query=${encodeURIComponent(searchId)}&realm=${encodeURIComponent(realm)}`
    : `https://${host}/api/trade/fetch/${path}?query=${encodeURIComponent(searchId)}`;
}
export function whisperUrl(realm, domain) {
  return `https://${hostFor(realm, domain)}/api/${apiSeg(realm)}/whisper`;
}
export function whisperBody(hideoutToken, force, realm, retry) {
  // In-demand RETRY (both games): the trade site's own "item is in demand — whisper again" second
  // click POSTs the same token plus continue:true — a BOOLEAN (browser capture 2026-07-31), while
  // the force-teleport `continue` below is the STRING 'true'. Retry wins over force: the re-send
  // must be byte-for-byte the site's own second click.
  if (retry) return { token: hideoutToken, continue: true };
  // `continue:'true'` is the trade site's "teleport anyway" override. Sent for BOTH games since
  // v1.3.0 (user directive): GGG unified the PoE1 trade backend with PoE2 (per-listing JWT live
  // channel, hideout_token field, whisper-triggered teleport — all live-observed), so the old
  // PoE1 exclusion was an assumption, not a measurement. `force` is off unless the user armed
  // Force teleport in the host, which is confirm-gated and never persisted.
  return force ? { token: hideoutToken, continue: 'true' } : { token: hideoutToken };
}
// Fetch payloads: implicitMods are plain strings, but explicitMods can come back as
// {description,hash,mods} objects whenever the search carries explicit stat filters. Flatten either
// shape to the readable line so the host (string-only parse) keeps them.
export function modLine(m) {
  if (typeof m === 'string') return m;
  if (m && typeof m.description === 'string') return m.description;
  return '';
}
export function normalizeMods(arr) {
  return Array.isArray(arr) ? arr.map(modLine).filter(s => s) : [];
}
export function parseFetchResult(json, ctx) {
  const out = [];
  const arr = (json && Array.isArray(json.result)) ? json.result : [];
  // Token field: PoE2 listings carry hideout_token; legacy PoE1 listings carry whisper_token; the
  // unified backend uses hideout_token for both (live-observed). Read both, PoE2-name first (mirrors
  // the host TLS parser). The item field name (`hideoutToken`) is "the token /whisper is POSTed with".
  for (const r of arr) {
    if (!r || !r.id) continue;
    const L = r.listing || {}, it = r.item || {}, price = L.price || {}, stash = L.stash || {}, acct = L.account || {};
    out.push({
      itemId: r.id,
      stashX: (typeof stash.x === 'number') ? stash.x : -1,
      stashY: (typeof stash.y === 'number') ? stash.y : -1,
      w: it.w || 1, h: it.h || 1,
      currency: price.currency || '', amount: price.amount || 0,
      seller: acct.name || '', stashName: stash.name || '',
      name: it.name || '', typeLine: it.typeLine || '', baseType: it.baseType || '', rarity: it.rarity || '',
      iconUrl: it.icon || '',
      ilvl: it.ilvl || 0, corrupted: !!it.corrupted, identified: it.identified !== false,
      explicitMods: normalizeMods(it.explicitMods),
      implicitMods: normalizeMods(it.implicitMods),
      league: (ctx && ctx.league) || '', realm: (ctx && ctx.realm) || '',
      hideoutToken: L.hideout_token || L.whisper_token || '', indexedTime: L.indexed || ''
    });
  }
  return out;
}
export function groupBySeller(items) {
  const map = new Map();
  for (const it of items) { const k = it.seller || '?'; if (!map.has(k)) map.set(k, []); map.get(k).push(it); }
  return [...map.entries()].map(([seller, items]) => ({ seller, items }));
}
export function selectLargestSeller(items, declaredCount) {
  const count = Number(declaredCount);
  if (!Number.isInteger(count) || count < 1 || count > 5 ||
      !Array.isArray(items) || items.length > count) return null;
  const groups = new Map();
  for (let index = 0; index < items.length; ++index) {
    const item = items[index];
    const seller = item && typeof item.seller === 'string' ? item.seller : '';
    if (!seller) continue;
    if (!groups.has(seller)) groups.set(seller, { seller, items: [], indexes: [] });
    const group = groups.get(seller);
    group.items.push(item);
    group.indexes.push(index);
  }
  let selected = null;
  for (const group of groups.values()) {
    if (!selected || group.items.length > selected.items.length) selected = group;
  }
  return selected;
}
// Currency profit filter, mirroring the host TLS path (WebSocketManager_TlsTrade.cpp): with no
// enabled filters the item passes (buy any); otherwise its currency must be present in `filters`
// and its amount within [min, max] (a 0 bound means unbounded).
export function passesCurrencyFilter(filters, item) {
  if (!filters || !Object.keys(filters).length) return true;
  const c = filters[item.currency];
  if (!c) return false;
  if (c.min > 0 && item.amount < c.min) return false;
  if (c.max > 0 && item.amount > c.max) return false;
  return true;
}

// --- pure decision helpers (mirrored, not imported, by the MAIN-world agent in background.js) ---
export function decideClaim({ hostReady, busy }) { return { grant: !!hostReady && !busy }; }

// --- live-search liveness supervision (field bug 2026-07-29: "an item was listed and the program
// logged nothing") -------------------------------------------------------------------------------
// The live pipeline is armed ONCE per page load and used to recover ONLY through `ws.onclose`.
// Every failure that removes the page agent WITHOUT a close event left the search silently dead
// forever — no WebSocket, no log line, no status change, while POEFixer kept showing it connected:
//   * the browser DISCARDS the background trade tab (Chrome Memory Saver / Edge sleeping tabs / OS
//     memory pressure). The manual-buy tab is already opted out of this; the search tabs were not.
//   * the tab (or its window) is closed, or the renderer crashes, or the page navigates/reloads —
//     the old code's one-way `injected` latch then refused to ever re-arm that tab.
//   * the socket goes half-open (laptop sleep, VPN/Wi-Fi drop, NAT timeout): no close event ever
//     arrives, so the agent looks healthy while receiving nothing.
// The supervisor below turns "armed once, hope for the best" into a state machine the service
// worker re-evaluates on every alarm tick. Timings: hidden tabs get their timers throttled to about
// once a minute, so a missed heartbeat alone is NOT proof of death — an overdue beat first triggers
// an on-demand probe (a runtime message, which is not timer-throttled), and only a long silence
// counts as dead. Recovery escalates: re-inject the agent, then reload the tab (the only way back
// from a frozen document), then reopen it.
export const LIVENESS = {
  beatMs: 20000,            // page agent -> service worker heartbeat cadence
  probeMs: 70000,           // beat overdue by this much -> probe the tab directly (just past the ~60 s
                            // intensive-throttle period, so a merely-throttled tab is not "overdue" forever)
  deadMs: 150000,           // no beat for this long -> the agent is gone; recover
  recoverGapMs: 60000,      // minimum gap between recovery attempts for one search
  navGapMs: 60000,          // first gap between "steer the tab back" navigations (backs off from there)
  injectTimeoutMs: 10000,   // executeScript never settles on a frozen tab — bound it or the search wedges
  injectStuckMs: 30000,     // an executeScript unsettled this long = the document is wedged; replace it
  parkStreak: 4,            // this many recoveries without a single heartbeat -> park the search
  parkRetryMs: 900000       // a parked search retries this often (instead of reopening every minute)
};

// Decide what the sweep must do for ONE armed search. Pure (clock + observations in, action out) so
// the whole policy is asserted offline in tests/trade.test.mjs.
export function decideSearchRecovery(s) {
  const now = s.now || 0;
  const cooling = !!s.lastRecoverAt && (now - s.lastRecoverAt) < LIVENESS.recoverGapMs;
  // An owed reconnect backoff (the 1013 penalty) is an ABSOLUTE barrier and comes before every
  // other rule: repairing a missing/frozen/discarded/wandered tab always ends in a page load, the
  // page load ends in an inject, and an upgrade attempted inside the penalty refreshes the penalty
  // (the 1.3.2 field regression: exactly these repairs kept users rate-limited for 30+ minutes).
  // While the backoff runs, the tab — whatever state it is in — is left completely alone.
  if (s.nextInjectAt && now < s.nextInjectAt)
    return { action: 'none', reason: 'waiting out the reconnect backoff' };
  // A search that keeps failing recovery is PARKED: reopening a tab every minute forever is 60
  // upgrades/hour spent on a search something else keeps killing (a broken relay, a profile that
  // cannot load the page). Parked searches still retry, on a long leash.
  if ((s.recoverStreak | 0) >= LIVENESS.parkStreak && !!s.lastRecoverAt &&
      (now - s.lastRecoverAt) < LIVENESS.parkRetryMs)
    return { action: 'none', reason: 'parked after repeated failed recoveries' };
  // Tab-level failures next: nothing can live in a tab that is gone, unloaded or frozen, so
  // probing or re-injecting one is wasted work. They are rate-limited like every other recovery —
  // whatever keeps discarding the tab (another extension, an OS under memory pressure) must not
  // turn into a reload, and a fresh live socket, on every single tick.
  if (s.tabMissing)
    return cooling ? { action: 'none', reason: 'recovery cooling down' }
                   : { action: 'reopen', reason: 'tab is gone' };
  // `frozen` is Chrome 132+ (undefined elsewhere, hence the strict check at the call site). A frozen
  // document runs no timers AND no event handlers, so only replacing it helps.
  if (s.discarded || s.frozen)
    return cooling ? { action: 'none', reason: 'recovery cooling down' }
                   : { action: 'reload', reason: s.frozen ? 'the browser froze the tab' : 'the browser discarded the tab' };
  if (s.loading) return { action: 'none', reason: 'page is still loading' };
  // The tab wandered off the search page (a login redirect, or the user typed something into it).
  // The agent only works on that page — its fetch and whisper use the site's own origin and
  // cookies — so the tab has to be steered back. This is checked BEFORE the liveness rules because
  // reloading or re-injecting a wrong page just repeats the wrong page.
  if (s.offPage) {
    // Backs off: a browser profile that is logged out redirects the search page to /login every
    // time, and steering it back once a minute forever is a loop nobody benefits from. The shift
    // EXPONENT is clamped (not the result): `1 << 31` is negative and `1 << 32` wraps to 1 —
    // either would break the ceiling after ~7.5 h of a permanently logged-out profile.
    const gap = LIVENESS.navGapMs * (1 << Math.min(Math.max(0, s.navStreak | 0), 4));
    return (now - (s.lastNavAt || 0) >= gap)
      ? { action: 'navigate', reason: 'tab left the search page' }
      : { action: 'none', reason: 'waiting before steering the tab back again' };
  }
  // A previous executeScript that never settled: the injection is QUEUED against a wedged document
  // (w3c/webextensions#527), and issuing more piles more queued agents that all land at thaw — each
  // opening its own socket. The only escalation is replacing the document, which strands the queued
  // inject on a dead page (and the monotonic generation makes it stand down even if it does land).
  if (s.injectStuck)
    return cooling ? { action: 'none', reason: 'recovery cooling down' }
                   : { action: 'reload', reason: 'a queued injection never landed' };
  // A persistently REJECTING executeScript (site access revoked, a crashed renderer whose tab
  // still reports the old URL and 'complete') escalates here. Its retry path re-schedules through
  // nextInjectAt, and 'scheduled reconnect' below deliberately skips the recover streak — without
  // this rule that loop ran forever: never reloaded (which revives a crashed document), never
  // parked, never reported. The reloads it triggers DO feed the streak, so park is reachable.
  if ((s.injectFailStreak | 0) >= 2)
    return cooling ? { action: 'none', reason: 'recovery cooling down' }
                   : { action: 'reload', reason: 'the agent cannot be injected' };
  // A reconnect scheduled by the backoff after a real ws close, now due. The sweep re-arms it
  // itself (instead of relying only on a setTimeout) so it survives a service-worker restart.
  if (s.nextInjectAt) return { action: 'inject', reason: 'scheduled reconnect' };
  if (s.busyHere) return { action: 'none', reason: 'buy in flight for this search' };
  const since = now - (s.lastBeatAt || 0);
  if (since >= LIVENESS.deadMs) {
    if (cooling) return { action: 'none', reason: 'recovery cooling down' };
    // Re-injecting is cheap and fixes the common case (page reloaded / agent gone). If a second
    // dead window passes, the document itself is unusable (frozen tab, wedged renderer) and only a
    // reload gets a fresh one. If even that does not restore the heartbeat, replace the tab: a
    // reload is not a documented way out of a frozen tab, closing it always is.
    const streak = s.recoverStreak | 0;
    if (streak >= 2) return { action: 'reopen', reason: 'still no heartbeat after a reload' };
    return streak >= 1
      ? { action: 'reload', reason: 'no heartbeat after re-arming' }
      : { action: 'inject', reason: 'no heartbeat' };
  }
  if (since >= LIVENESS.probeMs) return { action: 'probe', reason: 'heartbeat overdue' };
  return { action: 'none', reason: '' };
}

// Is this tab still sitting on THIS search's page? Deliberately loose: the trade site rewrites its
// own URL (query string, fragment, its own path tweaks), and treating a rewrite as "the tab wandered
// off" would navigate it in a loop and kill the very socket the supervisor exists to protect. Strict
// enough to catch what actually goes wrong — a login redirect, an error page, a tab the user typed
// something else into: same host, same product path, same league, and (for a legacy id) this
// search's own id.
//
// 0.5.5 (field log 2026-09-05): the PoE2 site RE-SPELLS the search id within a second of the page
// loading — it re-mints base64url(gzip(query)) from its own normalised query state and commits the
// new spelling as a same-document navigation. The host's string is therefore not on the URL for
// long and cannot be predicted (the field pair shared its first 15 characters and the gzip OS byte
// and diverged in the deflate body), and a search saved with a pre-0.5.5 short id is re-minted the
// same way. So for a PoE2 search the id slot is not compared at all: same host + product path +
// league is the page. That is enough for the ONE question this answers, "is my tab still on my
// page" — the page agent never reads the URL; its live socket and fetches carry the id the host
// pushed. Which tab is MINE is a different question (findExistingTab in background.js keeps a tab
// registry for it) and must never lean on this rule: two searches in one league are
// indistinguishable here by design. PoE1 ids are short and stable, so a PoE1 search keeps the
// exact-id rule.
export function isSearchTabUrl(url, search) {
  if (typeof url !== 'string' || !url) return true;   // unknown URL: never act on a guess
  return searchTabUrlMatch(url, search) !== null;
}
// 'exact' — the URL carries this search's own id (a PoE1 id, or a PoE2 tab caught before the site
// re-spelled it); 'page' — a PoE2 search's page under any other id (whatever the site minted: a
// compressed spelling today, a short canonical id tomorrow — neither may re-open the steering
// loop); null — not this search's page. Host is the search's own (hostFor: cookies differ per
// host), the realm segment is compared strictly so /trade and /trade2 never cross, the league is
// compared decoded ('+' tolerated as a space). A malformed URL is "not my page", never a throw —
// this runs inside the sweep and inside Array.find callbacks.
export function searchTabUrlMatch(url, search) {
  if (!search || typeof search.searchId !== 'string' || !search.searchId) return null;
  const p = parseSearchUrl(url);
  if (!p || !p.searchId) return null;
  if (p.domain !== hostFor(search.realm, search.domain)) return null;
  if ((p.realm || '') !== (search.realm || '')) return null;
  if (leagueKey(p.league) !== leagueKey(search.league)) return null;
  if (p.searchId === search.searchId) return 'exact';
  return isPoe2(search.realm) ? 'page' : null;
}
function leagueKey(s) { return String(s == null ? '' : s).replace(/\+/g, ' '); }

// Should the page agent recycle its live socket? Every recycle costs a WS upgrade, and the upgrade
// count IS the rate-limit budget (2026-06-10 RCA: ~12 upgrades/hour/connection across 10 searches
// was mass-1013 territory) — so only evidence that the socket is genuinely BROKEN qualifies:
//   * a handshake wedged in CONNECTING is a socket that will never deliver anything, and
//   * the beat timer not running for far longer than its own period is what a machine waking from
//     sleep looks like from in here — the one case where the socket is half-open with no close
//     event ever coming.
// Silence is NOT evidence: a narrow live search legitimately receives nothing for hours, and
// WebSocket keepalive is protocol-level (never surfaces to JS). Neither is the `online` event: it
// fires on any interface change, in every search tab at once — recycling on it threw away N healthy
// sockets in one tick, which is the exact burst shape GGG answers with a 1013 (the 1.3.2 field
// regression). Mirrored by the MAIN-world agent.
export function shouldRecycleSocket({ connectingMs, beatGapMs }) {
  if ((connectingMs | 0) > 30000) return true;        // handshake wedged in CONNECTING
  return (beatGapMs | 0) >= Math.max(LIVENESS.beatMs * 5, LIVENESS.deadMs);
}
// --- global fleet WS-upgrade gate ----------------------------------------------------------------
// GGG's live-search rate limit is enforced on the WS UPGRADE, budgeted per account and shared by
// every search — but until 1.3.3 every search reconnected on its own schedule, so N searches
// answering the same event (a network blip, a sleep-wake, one config push) landed N handshakes in
// one tick, and one 1013 snowballed into a mass penalty. This gate is the ONE choke point every
// upgrade passes through (armAgentInner is the single place a live agent — and so a live socket —
// is created):
//   * spacing: any two upgrades, for any two searches, are at least minGapMs (+ jitter) apart;
//   * episodes: sub-healthy closes (the 1013 shape: accept-then-close within seconds) clustering
//     fleet-wide hold ALL upgrades for an escalating window, because a penalty that is already
//     running is only refreshed by more attempts.
// Pure state-in/state-out so the whole policy is asserted offline; the service worker owns one
// state object and persists it best-effort across restarts.
export const UPGRADE_GATE = {
  minGapMs: 2000,           // fleet-wide minimum spacing between any two WS upgrades
  jitterMs: 1500,           // extra per-grant spread so deferred searches do not re-collide
  failWindowMs: 600000,     // sub-healthy closes within this rolling window cluster into an episode
  failThreshold: 3,         // this many clustered failures -> hold the whole fleet
  holdBaseMs: 60000,        // first fleet hold; doubles per episode
  holdMaxMs: 600000,        // cap for the generic (non-1013) episode ladder
  calmMs: 300000,           // this long without a failure -> the GENERIC streak resets (see below
                            // for why the 1013 streak needs evidence, not calm)
  // Hourly upgrade BUDGET (1.3.8, field RCA 2026-08-05). The spacing rule above bounds the RATE of
  // a burst; it cannot bound the TOTAL — a client's browser reloaded every search tab ~every 2-3.5
  // min (an auto-refresh tool; the extension ordered none of it), each reload re-armed the agent =
  // one upgrade, ~71/hour, and after 67 min GGG penalized the account. The budget is the invariant
  // the spacing rule is not: whatever keeps replacing the documents, the fleet cannot spend past it.
  // Sizing: the 2026-06-10 RCA pegs ~12 upgrades/hour/connection (~120/h fleet) as mass-1013; the
  // field case penalized ~71/h. 6/search/h is half the per-connection figure; the floor leaves one
  // search room for bring-up plus a genuinely bad hour of recoveries (sleep-wakes, OS discards);
  // the ceiling keeps a big fleet's total at ~40% of the observed-penalized rate.
  budgetWindowMs: 3600000,  // rolling hour
  budgetPerSearchPerHour: 6,
  budgetMin: 15,            // floor: a fleet of 1-2 searches still recovers through a bad hour
  budgetFleetMax: 30,       // ceiling: the account is ONE budget no matter how many searches share it
  // Close code 1013 escalation. 1013 is the server SAYING "try again later" — per-ACCOUNT (the
  // site's own banner: "Rate-limiting is active for your account"), so one is enough to hold every
  // search. The generic ladder capped at 10 min and the per-search backoff at 5 min; in the field
  // that meant a 4-search fleet attempted every 1-4 min, and an upgrade attempted inside the
  // penalty REFRESHES the penalty (the 1.3.2 finding) — 46 min rate-limited until the user gave up.
  // The ladder must reach real silence: 3 -> 6 -> 12 -> 24 -> 30 min cap.
  hold1013BaseMs: 180000,
  hold1013MaxMs: 1800000
};
export function newGateState() { return { nextFreeAt: 0, fails: [], holdUntil: 0, holdStreak: 0, lastFailAt: 0, opens: [], streak1013: 0 }; }
// Ask to open ONE live-WS upgrade. 0 = granted (the slot is booked); >0 = try again in this many ms.
// `rand` ∈ [0,1) is passed in (not drawn here) so the policy stays deterministic under test.
// `searchCount` sizes the hourly budget (missing = a fleet of one — old callers stay correct).
// Booking happens at RESERVE, not at open: every grant becomes an upgrade ATTEMPT, and attempts are
// what GGG counts — a 1013'd attempt spends budget exactly like a healthy one.
export function gateReserve(g, now, rand, searchCount) {
  const at = Math.max(g.nextFreeAt, g.holdUntil);
  if (now < at) return at - now;
  g.opens = (g.opens || []).filter(t => now - t < UPGRADE_GATE.budgetWindowMs);
  const budget = Math.min(UPGRADE_GATE.budgetFleetMax,
                          Math.max(UPGRADE_GATE.budgetMin,
                                   UPGRADE_GATE.budgetPerSearchPerHour * Math.max(1, searchCount | 0)));
  // Over budget: the wait points at the moment the OLDEST booking slides out of the rolling hour.
  if (g.opens.length >= budget) return (g.opens[0] + UPGRADE_GATE.budgetWindowMs) - now;
  g.opens.push(now);
  g.nextFreeAt = now + UPGRADE_GATE.minGapMs + Math.floor((+rand || 0) * UPGRADE_GATE.jitterMs);
  return 0;
}
export function gateRecordClose(g, now, healthy, code) {
  if (healthy) { gateRecordHealthy(g, now); return; }
  g.lastFailAt = now;
  // 1013 is an explicit account-wide "try again later": ONE holds the whole fleet, immediately —
  // waiting for the generic 3-strike cluster meant the other searches kept attempting (and each
  // attempt refreshes the penalty). Other close codes keep the cluster rule: a lone network flake
  // must not silence the fleet for minutes.
  if ((code | 0) === 1013) {
    g.streak1013 = (g.streak1013 | 0) + 1;
    g.holdUntil = Math.max(g.holdUntil,
      now + Math.min(UPGRADE_GATE.hold1013BaseMs * Math.pow(2, g.streak1013 - 1), UPGRADE_GATE.hold1013MaxMs));
    return;
  }
  g.fails.push(now);
  g.fails = g.fails.filter(t => now - t <= UPGRADE_GATE.failWindowMs);
  if (g.fails.length >= UPGRADE_GATE.failThreshold) {
    g.holdStreak++;
    g.fails = [];
    g.holdUntil = now + Math.min(UPGRADE_GATE.holdBaseMs * Math.pow(2, g.holdStreak - 1), UPGRADE_GATE.holdMaxMs);
  }
}
// A socket reaching OPEN is the only success signal worth acting on — and only a calm stretch since
// the last failure ends an escalation (an open during trouble is routine: 1013s accept-then-close,
// so opens keep happening right through a penalty).
export function gateRecordOpen(g, now) {
  if (g.lastFailAt && now - g.lastFailAt > UPGRADE_GATE.calmMs) g.holdStreak = 0;
}
// HEALTHY-SOCKET EVIDENCE ends every escalation. The 1013 streak cannot reset on a calm timer:
// during a long hold the gap between attempts IS the hold, so any time-based calm fires mid-
// escalation and the ladder never climbs. A socket that LIVED a healthy stretch is proof the
// account is not penalized right now — background.js reports it from two places (a healthy close,
// and a beat whose socket has been open past the healthy threshold, because a healthy socket may
// not close for hours).
export function gateRecordHealthy(g, now) {
  g.streak1013 = 0;
  g.holdStreak = 0;
  g.fails = [];
}

// --- external-reload detector --------------------------------------------------------------------
// The budget above caps what an external tab-reloader can SPEND; this names the reloader so the
// user can remove it. Field case 2026-08-05: an auto-refresh tool reloaded every search tab
// ~every 2-3.5 min for two hours and the extension's log looked CLEAN — every reload path the
// extension owns logs a reason, and a superseded agent's socket close is swallowed by design, so
// nothing recorded the burn until the account was penalized. background.js counts document
// replacements it did NOT order (its own reload/reopen/navigate/adopt paths mark themselves) and
// warns at a rate no legitimate use reaches. Threshold: 8 un-ordered replacements in 30 min =
// sustained ≤3.75 min apart = 16/hour — over twice the per-search budget, and a rate only a timer
// produces (the field reloader ran at ~9-20/30 min per tab).
export const RELOAD_WATCH = {
  windowMs: 1800000,        // look back 30 min
  threshold: 8,             // this many un-ordered replacements in the window -> warn
  warnGapMs: 900000         // repeat the warning at most every 15 min per search
};
export function detectExternalReloads(times, now) {
  const w = (times || []).filter(t => now - t < RELOAD_WATCH.windowMs);
  return { count: w.length, external: w.length >= RELOAD_WATCH.threshold, times: w };
}

// --- generation ordering (queued-inject self-cancel) ---------------------------------------------
// executeScript against a frozen tab is queued, not failed — so injections can land LATE, after a
// newer generation already armed. "Last to run wins" is exactly backwards there: the stale agent
// would stamp its old generation over the live one, tear the live agent down and open one more
// socket. Generations are monotonic numbers; an agent yields to any equal-or-newer generation it
// finds on the page. A string is the pre-1.3.3 uuid shape — its ordering is meaningless, so never
// yield to it (the newcomer is the newer of the two by construction). Mirrored by pfxLiveAgent.
export function agentShouldYield(genOnPage, myGen) {
  return typeof genOnPage === 'number' && typeof myGen === 'number' && genOnPage >= myGen;
}

// Host config.behavior normalization (background.js applyConfig imports this; the MAIN-world agents
// receive the already-normalized object via inject args / pushCtl). `ingame` gates all trade actions:
// false ⇒ live agents drop incoming ids pre-fetch and refuse whispers; MISSING ⇒ true (an old host
// that doesn't send the flag keeps the extension fully working).
export function normalizeBehavior(b) {
  b = b || {};
  return {
    forceTeleport: !!b.forceTeleport,
    inDemandRetry: !!b.inDemandRetry,
    rateLimit: !!b.rateLimit,
    ingame: b.ingame === false ? false : true,
    packetBatch: !!b.packetBatch,
    // Why the host shut the gate, as one short token (host: ExtWhisperBlockReason). '' whenever
    // the host did not say — which is every host older than 1.4.1, and every open gate.
    // Normalized to a STRING here so no caller can concatenate `undefined` into a log line.
    pauseReason: typeof b.pauseReason === 'string' ? b.pauseReason : ''
  };
}
// Human text for behavior.pauseReason, for the one thing the user actually reads: the line that
// says buying is paused. There used to be a single wording for every cause — "not in game" —
// so a safety stop, a loading screen, an auto-stash trip and the pause hotkey were indistinguishable,
// and the line read as a mystery stop while the character stood in its own hideout.
//
// Two deliberate fallbacks:
//   * NO token (an older host, which never sends one) reads "not in game" — exactly what this
//     line said before, so nothing regresses and nothing prints "undefined";
//   * an UNKNOWN token is rendered verbatim, underscores to spaces. A host newer than this
//     extension has a real cause to report, and reporting it beats reporting a wrong one.
const PAUSE_REASON_TEXT = {
  not_in_game: 'not in game',
  no_session: 'no trade session',
  stash_busy: 'stash busy',
  safety_stop: 'safety stop',
  afk_recovery: 'AFK recovery',
  shutdown: 'host shutting down',
  paused: 'paused by hotkey',
  stopped: 'trading stopped'
};
export function pauseReasonText(behavior) {
  const raw = (behavior && typeof behavior.pauseReason === 'string') ? behavior.pauseReason : '';
  if (!raw) return 'not in game';
  // `safety_stop:currency_stuck` — the head names the class of stop, the tail names the failure.
  const cut = raw.indexOf(':');
  const head = (cut < 0 ? raw : raw.slice(0, cut)).slice(0, 60);
  const tail = (cut < 0 ? '' : raw.slice(cut + 1)).slice(0, 60);
  const text = PAUSE_REASON_TEXT[head] || head.replace(/_/g, ' ') || 'not in game';
  return tail ? text + ': ' + tail.replace(/_/g, ' ') : text;
}
// Not-in-game gate. Mirrored, not imported, by the MAIN-world agents: behavior.ingame === false ⇒
// drop/refuse; true / missing / no behavior yet ⇒ allowed.
export function ingameAllowed(behavior) { return !(behavior && behavior.ingame === false); }
export function whisperOutcome({ ok, inDemand }) { return ok ? 'ok' : (inDemand ? 'in_demand' : 'error'); }
export function tradeEventPayload(stage, outcome, item, detail) {
  return { stage, outcome, itemId: (item && item.itemId) || '', detail: detail || '', item: item || null };
}

// --- Manual-buy rate-limit policy (SW-side; the MAIN-world bursts inline a MIRROR of the parse).
// A stated penalty is honoured IN FULL: every request made inside it refreshes it (field-proven —
// the ≤30 s nibble turned one 429 into a 1706 s ban), so the only working move is to sit it out.
// Clamped both ways: never spin on a ~0 hint, never park forever on a garbage one.
export const MB_RATE = { minMs: 5000, maxMs: 3600000, streakMax: 3, escalateCapMs: 120000, escalateMultMax: 4 };
// Math.trunc, NOT `| 0`: an int32 coercion wraps a garbage wait >= 2^31 ms (~24.9 days) negative,
// which the floor then turns into a 5 s retry cadence inside a live penalty — the exact refresh
// loop this clamp exists to prevent. Math.trunc(NaN) || 0 keeps non-numeric input at the floor.
export function clampMbRateWait(ms) { return Math.min(MB_RATE.maxMs, Math.max(MB_RATE.minMs, Math.trunc(+ms) || 0)); }
// "wait N seconds" — regex-only by rule: a bare number in a message is NEVER a wait (a lone "1013"
// once parsed as 1013 seconds froze the native client for 17 minutes).
export function waitHintMs(message) {
  const m = /wait\s+(\d+)\s+seconds/i.exec(message || '');
  return m ? parseInt(m[1], 10) * 1000 : 0;
}
// One verdict for one trade-site answer: 0 = not a rate limit, else the FULL stated wait in ms.
// Recognizes HTTP 429 (Retry-After header and/or body hint, whichever is larger) and the in-band
// {"error":{"code":3,"message":"Rate limit exceeded; ..."}} shape the site sends on a 2xx.
export function rateLimitMsOf({ status, retryAfter, body }) {
  const err = body && body.error;
  const em = err ? String(err.message || '') : '';
  const inBand = !!(err && (err.code === 3 || /rate limit/i.test(em)));
  if (status !== 429 && !inBand) return 0;
  const ra = status === 429 ? (parseInt(retryAfter, 10) || 0) * 1000 : 0;
  return Math.max(ra, waitHintMs(em)) || (status === 429 ? 10000 : 60000);
}
// What the bulk loop does with a rate-limited request: wait the full clamped penalty, then retry
// the SAME work — up to streakMax consecutive rate-limited attempts, after which it counts the
// group failed and moves on (still after the wait — the penalty gates the NEXT request too).
export function decideMbRate(rateMs, streak) {
  if (!rateMs || rateMs <= 0) return { action: 'none', waitMs: 0 };
  return { action: streak >= MB_RATE.streakMax ? 'fail' : 'retry', waitMs: clampMbRateWait(rateMs) };
}
// Escalating wait for consecutive rate-limited fetch/search BURSTS (2026-08-05 field log): the
// site kept answering with a 10 s hint and the loop re-ran resolve+POST+fetch every ~13 s — a
// drumbeat that alone sustains a saturated long-window quota, so the user saw "manual buy
// doesn't work at all". A SHORT hint grows with the streak (x2, x3 … up to escalateMultMax,
// never past escalateCapMs); a LONG stated penalty is already the wait and passes through
// untouched. The whisper path deliberately stays 1x — it is bounded by streakMax per group.
export function escalateMbWait(rateMs, streak) {
  const base = clampMbRateWait(rateMs);
  if (base >= MB_RATE.escalateCapMs) return base;
  const mult = Math.min(Math.max(streak | 0, 1), MB_RATE.escalateMultMax);
  return Math.min(base * mult, MB_RATE.escalateCapMs);
}

// --- network wrappers (browser; use credentials for cookies). Rate-limit aware. ---
let _rateGateUntil = 0;
export function rateGateMsLeft() { return Math.max(0, _rateGateUntil - Date.now()); }
function _applyRateHeaders(resp) {
  // GGG sends X-Rate-Limit-* + Retry-After on 429. Back off if present.
  const ra = resp.headers.get('Retry-After');
  if (resp.status === 429 && ra) _rateGateUntil = Date.now() + (parseInt(ra, 10) || 5) * 1000;
}
// The JSON GET header shape, and the reference copy of it: the three MAIN-world GETs in
// background.js mirror this object literal, because executeScript(world:'MAIN') serialises a
// function by toString() and so cannot import one.
//
// All three names are needed and none of them arrive on their own. `fetch` adds no
// X-Requested-With under any circumstance — the header only ever comes from application code —
// and a real trade-site GET carries it on both engines (captures C-2, F-2). Accept-Language is
// CORS-safelisted, and the site sets a bare `en-US` on this endpoint while letting the browser's
// own chain ride the whisper POST and the live-search upgrade; so this is the one request kind
// where the value is a site literal rather than a user property, and it must NOT be copied onto
// the POSTs below.
//
// Boundary, same as the host's TradeRequestShapes.h: `en-US` is measured on the English
// www.pathofexile.com only. Whether a localised trade host sets a different value is unmeasured;
// if one ever does, this becomes per-domain.
export const JSON_GET_HEADERS = { 'Accept': 'application/json', 'Accept-Language': 'en-US', 'X-Requested-With': 'XMLHttpRequest' };
export async function fetchItems({ realm, searchId, ids, jwt, domain }) {
  const resp = await fetch(fetchUrl({ realm, searchId, ids, jwt, domain }), { credentials: 'include', headers: { ...JSON_GET_HEADERS } });
  _applyRateHeaders(resp);
  if (!resp.ok) throw new Error('fetch ' + resp.status);
  const json = await resp.json();
  return parseFetchResult(json, { realm });
}
export async function sendWhisper({ realm, hideoutToken, force, domain, retry }) {
  const resp = await fetch(whisperUrl(realm, domain), {
    method: 'POST', credentials: 'include',
    headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest', 'Accept': '*/*' },
    body: JSON.stringify(whisperBody(hideoutToken, force, realm, retry))
  });
  _applyRateHeaders(resp);
  let body = {}; try { body = await resp.json(); } catch {}
  // Surface the server's own explanation (e.g. "…must be in-game…") — a bare status is undiagnosable.
  const msg = (body && body.error) ? String(body.error.message || body.error.code || '') : '';
  // BOTH games: success true => teleporting; success false with NO error => "in demand" (another
  // buyer whispered first — retried once when the host armed it). The old PoE1 exclusion here was
  // an assumption, disproven 2026-07-31 (field report + browser capture).
  const inDemand = !!(body && body.success === false && !body.error);
  return { ok: resp.ok && body && body.success === true, inDemand, status: resp.status, msg, body };
}
