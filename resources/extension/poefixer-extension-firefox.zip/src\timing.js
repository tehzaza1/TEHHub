export const TIMING_VERSION = 1;
const MAX_STAGES = 16;
const MAX_STAGE_MS = 3_600_000;
const MAX_TOTAL_MS = 7_200_000;
const OUTCOMES = new Set(['ok', 'failed', 'timeout', 'cancelled', 'degraded', 'skipped']);

export function createTimingDraft(source) {
  return { source: typeof source === 'string' ? source : '', partial: false, stages: [] };
}

export function addMeasuredStage(draft, key, startMs, endMs, outcome = 'ok') {
  if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs < startMs) return false;
  return appendDuration(draft, key, Math.round(endMs - startMs), outcome);
}

export function appendDuration(draft, key, durationMs, outcome = 'ok') {
  if (!draft || !Array.isArray(draft.stages) || typeof key !== 'string' || !key ||
      !Number.isFinite(durationMs) || !OUTCOMES.has(outcome)) return false;
  const duration = Math.round(durationMs);
  if (duration < 0 || duration > MAX_STAGE_MS) return false;

  const currentTotal = draft.stages.reduce(
    (sum, stage) => sum + (Number.isFinite(stage.durationMs) ? Math.max(0, Math.round(stage.durationMs)) : 0), 0);
  if (currentTotal + duration > MAX_TOTAL_MS) return false;

  const previous = draft.stages[draft.stages.length - 1];
  if (previous && previous.key === key && Number.isFinite(previous.durationMs)) {
    const merged = Math.round(previous.durationMs) + duration;
    if (merged > MAX_STAGE_MS) return false;
    previous.durationMs = merged;
    if (outcome !== 'ok') previous.outcome = outcome;
    return true;
  }
  if (draft.stages.length >= MAX_STAGES) return false;
  draft.stages.push({ key, durationMs: duration, outcome });
  return true;
}

export function finalizeTiming(draft, sentAtUnixMs = Date.now()) {
  const normalized = createTimingDraft(draft && draft.source);
  normalized.partial = !!(draft && draft.partial);
  for (const stage of (draft && Array.isArray(draft.stages)) ? draft.stages : []) {
    if (Number.isFinite(stage.startMs) && Number.isFinite(stage.endMs))
      addMeasuredStage(normalized, stage.key, stage.startMs, stage.endMs, stage.outcome || 'ok');
    else
      appendDuration(normalized, stage.key, stage.durationMs, stage.outcome || 'ok');
  }
  const sent = Number.isFinite(sentAtUnixMs) && sentAtUnixMs > 0
    ? Math.round(sentAtUnixMs) : Date.now();
  return {
    version: TIMING_VERSION,
    source: normalized.source,
    partial: normalized.partial,
    sentAtUnixMs: sent,
    stages: normalized.stages.map(stage => ({ ...stage }))
  };
}

export function buildTimingPong(ping, receivedAtUnixMs, sentAtUnixMs) {
  return {
    type: 'timing_pong',
    nonce: String((ping && ping.nonce) || ''),
    hostSentUnixMs: Number(ping && ping.hostSentUnixMs),
    extensionReceivedUnixMs: Math.round(receivedAtUnixMs),
    extensionSentUnixMs: Math.round(sentAtUnixMs)
  };
}
