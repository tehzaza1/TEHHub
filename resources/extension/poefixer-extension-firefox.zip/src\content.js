// Relay between the MAIN-world page agent (window.postMessage) and the background service worker.
// The agent (injected via chrome.scripting world:'MAIN') runs the whole trade-site pipeline in
// the page; this isolated-world content script has chrome.runtime, so it bridges the two.
// All page-context messages are wrapped under a random per-session token (CH) so the trade page
// sees no fixed markers; CH is fetched from the background once on load.
let CH = null;
// One nonce per DOCUMENT, minted here at document_start and sent with every getCh (the retry loop
// below re-sends the same one). It is how the service worker tells a NEW document — a real
// navigation runs a fresh content script — from the site's own same-document URL rewrites, which
// run nothing: 0.5.5 re-spells the search id right after every load, and `tabs.onUpdated` reports
// that exactly like a reload (field log 2026-09-05).
const DOC = (function () {
  try { if (crypto && crypto.randomUUID) return crypto.randomUUID(); } catch (e) {}
  return 'd' + Math.random().toString(36).slice(2) + Date.now().toString(36);
})();
// Page messages that arrive before the token does. The agent is injected at document-complete and
// starts talking immediately, so its first lines (including the live socket coming up) could land
// in that gap and were simply dropped — a silent hole in the one channel that reports trouble.
const preCh = [];
(function fetchCh() {
  try {
    chrome.runtime.sendMessage({ cmd: 'getCh', doc: DOC }, (resp) => {
      if (chrome.runtime.lastError || !resp || !resp.ch) { setTimeout(fetchCh, 500); return; }
      CH = resp.ch;
      for (const e of preCh.splice(0, preCh.length)) relay(e);
    });
  } catch (e) { setTimeout(fetchCh, 500); }   // worker asleep / context invalidated: keep trying
})();

window.addEventListener('message', (e) => {
  if (e.source !== window || e.origin !== location.origin || !e.data || typeof e.data !== 'object') return;
  if (!CH) { if (preCh.length < 32) preCh.push(e); return; }
  relay(e);
});
// A document restored from the back/forward cache runs no content script again, so it re-announces
// itself: the page agent came back with it, but its socket did not (a page with an open socket is
// not cached), and the worker has to re-arm it.
window.addEventListener('pageshow', (e) => { if (e && e.persisted) bg({ cmd: 'getCh', doc: DOC, restored: true }); });

// One guarded way to reach the service worker. Both failure shapes are real: the promise rejects
// when no worker answers, and the call THROWS outright once the extension context is invalidated
// (an extension update orphans this content script). Neither may take down the relay — and a claim
// that cannot be delivered must be answered `false` at once instead of stalling the agent for its
// full timeout.
function bg(msg, cb) {
  try {
    const p = cb ? chrome.runtime.sendMessage(msg, cb) : chrome.runtime.sendMessage(msg);
    if (p && typeof p.catch === 'function') p.catch(() => {});
  } catch (e) { if (cb) { try { cb(null); } catch (e2) {} } }
}

function relay(e) {
  const d = e.data[CH];
  if (!d) return;
  // `g` is the agent's generation token: the background uses it to ignore an agent that has already
  // been superseded by a re-arm (see armAgent/genOk in background.js).
  switch (d.t) {
    case 'open':       bg({ cmd: 'searchOpen', sid: d.sid, g: d.g }); break;
    case 'close':      bg({ cmd: 'searchClose', sid: d.sid, g: d.g, code: d.code, reason: d.reason }); break;
    case 'beat':       bg({ cmd: 'beat', sid: d.sid, g: d.g, open: d.open, idleMs: d.idleMs }); break;
    case 'buy':        bg({ cmd: 'buy', sid: d.sid, g: d.g, prepareId: d.prepareId || '', group: d.group, timingDraft: d.timingDraft || (d.group && d.group.timingDraft) }); break;
    case 'tradeevent': bg({ cmd: 'tradeEvent', stage: d.stage, outcome: d.outcome, itemId: d.itemId, detail: d.detail, item: d.item, timingDraft: d.timingDraft }); break;
    case 'log':        bg({ cmd: 'extlog', message: d.message }); break;
    case 'claim':      bg({ cmd: 'claim', sid: d.sid, g: d.g }, (resp) => window.postMessage({ [CH]: Object.assign({ ctl: d.sid, grant: !!(resp && resp.grant) },
                           resp ? (resp.reason ? { reason: resp.reason } : {}) : { reason: 'relay_unreachable' }) }, location.origin)); break;
    case 'prepare':    bg({ cmd: 'prepare', sid: d.sid, g: d.g, key: d.key, origin: d.origin || 'live', group: d.group }, (resp) => window.postMessage({ [CH]: {
                           ctl: d.sid, prepareKey: d.key, ready: !!(resp && resp.ready),
                           prepareId: (resp && resp.prepareId) || '', error: (resp && resp.error) || ''
                         } }, location.origin)); break;
    case 'cancelPrepare': bg({ cmd: 'cancelPrepare', sid: d.sid, g: d.g,
                              prepareId: d.prepareId || '', reason: d.reason || 'cancelled' }); break;
    case 'release':    bg({ cmd: 'release', sid: d.sid }); break;
    case 'mbprogress': bg({ cmd: 'mbprogress', processed: d.processed, bought: d.bought, failed: d.failed, total: d.total }); break;
    case 'mbdone':     bg({ cmd: 'mbdone', state: d.state, processed: d.processed, bought: d.bought, failed: d.failed, total: d.total, detail: d.detail }); break;
    default: break;
  }
}

// Background -> page agent control channel (host ready state + behavior settings + liveness probe).
chrome.runtime.onMessage.addListener((req, _sender, sendResponse) => {
  // "Which document are you?" — asked at every load-complete (background.js reconcileDocument).
  // Answered before anything else: the token may still be on its way, the nonce never is.
  if (req && req.cmd === 'announce') { if (typeof sendResponse === 'function') sendResponse({ doc: DOC }); return; }
  if (!CH) return;
  if (req && req.cmd === 'ctl') window.postMessage({ [CH]: { ctl: req.searchId, ready: req.ready, behavior: req.behavior, filters: req.filters } }, location.origin);
  // Liveness probe: hidden tabs get their timers throttled to about once a minute, so an overdue
  // heartbeat is asked for directly rather than assumed to mean the agent is gone.
  if (req && req.cmd === 'probe') window.postMessage({ [CH]: { ctl: req.searchId, probe: true } }, location.origin);
  if (req && req.cmd === 'mbctl') window.postMessage({ [CH]: { ctl: req.id, mbcancel: !!req.cancel, buydone: !!req.buydone } }, location.origin);
});
