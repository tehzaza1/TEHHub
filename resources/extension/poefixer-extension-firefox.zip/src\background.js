import { PtbpClient } from './ptbp.js';
import { liveWsUrl, searchPageUrl, hostFor, groupBySeller, normalizeBehavior, pauseReasonText,
         LIVENESS, decideSearchRecovery, isSearchTabUrl, searchTabUrlMatch,
         newGateState, gateReserve, gateRecordClose, gateRecordOpen, gateRecordHealthy,
         RELOAD_WATCH, detectExternalReloads,
         MB_RATE, clampMbRateWait, decideMbRate, escalateMbWait } from './trade.js';
import { createTimingDraft, addMeasuredStage, finalizeTiming } from './timing.js';
import * as store from './storage.js';

// Program-controlled model. POEFixer pushes searches + behavior (config). For each search the
// extension opens a pinned bg tab to the trade page and injects a MAIN-world agent that runs the
// WHOLE trade-site pipeline IN THE PAGE (live WS + fetch + whisper) — identical Origin/Referer/
// cookies to the site (+ X-Requested-With for the whisper), so no 403. The agent posts buy
// requests out; the background relays them to POEFixer over PTBP and pushes host ready/behavior in.
let ptbp = null;
let hostReady = false;
let hostBehavior = { forceTeleport: false, inDemandRetry: true, rateLimit: true, ingame: true, packetBatch: false, pauseReason: '' };
// prepareId -> the live agent generation that armed it.  A superseded agent may still finish an
// already-started whisper, but no page message may bind or cancel somebody else's preparation.
const preparedOwners = new Map();
const logBuf = [];
// searchId -> { tabId, search, injected, lastOpenAt, failStreak, gen, genLast, lastBeatAt,
//               nextInjectAt, lastRecoverAt, recoverStreak, arming, injectPending, injectIssuedAt }
// `gen` is the generation token of the agent currently owning that tab's document: every inject
// mints a new one (MONOTONIC per search — clock-based, so it stays ordered across a service-worker
// restart), the page keeps only the NEWEST-numbered one, and anything another generation says is
// ignored (so re-arming can never leave two agents — i.e. two whispers — racing in one document,
// even when a queued executeScript lands late; see agentShouldYield in trade.js).
const searchTabs = new Map();

// Global fleet WS-upgrade gate (policy + tests in trade.js). armAgentInner is the ONLY place a live
// agent — and so a live socket — is created, so reserving here paces every upgrade the extension
// makes: config pushes, reconnects, recoveries, sleep-wakes. Persisted best-effort so a
// service-worker restart (which is exactly when a whole fleet re-arms at once) cannot shed an
// escalation that is still running.
const wsGate = newGateState();
(async () => { try { const r = await chrome.storage.session.get('wsgate'); if (r && r.wsgate) Object.assign(wsGate, r.wsgate); } catch (e) {} })();
function saveGate() { try { chrome.storage.session.set({ wsgate: wsGate }); } catch (e) {} }
// Throttle for the account-wide 1013 announcement: N searches usually 1013 within seconds of each
// other, and one banner says everything the five would.
let last1013LogAt = 0;

// A document replacement the extension did NOT order (its own reload/reopen/navigate/adopt paths
// set t.expectNav first). Counted per search; past RELOAD_WATCH.threshold in the window the user is
// told, loudly — the 2026-08-05 field case ran an auto-refresh tool against every search tab for
// two hours, the extension's own log stayed clean by design (a superseded agent's close is
// swallowed), and the first visible symptom was the account-wide penalty. Policy + tests in
// trade.js; the budget in gateReserve is what actually stops the spend.
function noteUnorderedReload(t) {
  const now = Date.now();
  const d = detectExternalReloads([...(t.reloadTimes || []), now], now);
  t.reloadTimes = d.times.slice(-16);
  if (d.external && now - (t.lastReloadWarnAt || 0) > RELOAD_WATCH.warnGapMs) {
    t.lastReloadWarnAt = now;
    log(`Search tab for ${t.search.note} was reloaded ${d.count} times in the last ${Math.round(RELOAD_WATCH.windowMs / 60000)} min by something OUTSIDE this extension — a browser auto-refresh feature/extension or manual refreshes. Every reload costs one live-search connection from the account's hourly budget; at this rate the trade site will rate-limit the WHOLE account. Find and disable whatever is reloading pathofexile.com tabs.`);
  }
}

// === Which document is the agent in? (1.4.3, field log 2026-09-05) ==============================
// `tabs.onUpdated` cannot tell a real navigation from the site's own same-document URL rewrite:
// Chrome reports BOTH as {status:'loading'} then {status:'complete'} (tabs_event_router.cc commits
// every navigation entry, same-document included). 0.5.5 made that distinction load-bearing — the
// trade site re-spells a compressed search id within a second of every page load — and the old
// 'loading' handler, which reset the agent's generation on every load event, orphaned a perfectly
// healthy agent on every rewrite: its open/beat/claim were refused as stale, the host never heard
// 'connected' ("Linking..." forever) and every listing was dropped. The document itself is the
// identity now: content.js runs once per NEW document (document_start) and announces a per-document
// nonce with its getCh; a same-document navigation runs nothing. A document with no content script
// at all (an error page) is caught at 'complete' by a probe that nothing answers.
function documentReplaced(t) {
  t.injected = false; t.gen = null; t.injectPending = false; t.lastBeatAt = Date.now();
  if (!t.loadStartedAt) t.loadStartedAt = Date.now();
  // Did WE order this replacement? Our reload/reopen/navigate/adopt paths mark themselves with
  // expectNav (one document consumes one mark). Anything else — an auto-refresh tool, a browser
  // feature, a user F5 — is counted and, sustained, warned about (2026-08-05 field RCA).
  if (t.expectNav) t.expectNav = false;
  else noteUnorderedReload(t);
}
// A content script announced itself (getCh). Synchronous on purpose: the reset must be on the books
// before the reply goes out, and a retried getCh (content.js re-asks every 500 ms until answered)
// carries the SAME nonce and must be a no-op — resetting twice would null a generation that a
// 'complete'-driven arm published in between. Returns the entry when a new document was recorded.
function noteDocument(sender, req) {
  const tab = sender && sender.tab;
  if (!tab || tab.id == null) return null;                          // the popup, not a page
  if (sender.frameId != null && sender.frameId !== 0) return null;  // top frame only
  const [sid, t] = entryForTab(tab.id);
  if (!t) return null;
  const nonce = (req && typeof req.doc === 'string') ? req.doc : '';
  // A bfcache restore re-announces the same nonce with `restored`: the document is back, but its
  // socket is not (a page with an open socket is not cached) — treat it as new and re-arm.
  if (nonce && nonce === t.docNonce && !(req && req.restored)) return null;
  t.docNonce = nonce;
  if (req && req.restored) t.expectNav = true;   // the user's own back/forward, not a reloader
  documentReplaced(t);
  return { sid, t };
}
// Every load-complete asks the tab which document it is showing (content.js answers with its
// per-document nonce; a document with no content script — an error page — answers nothing), and
// that answer, not the event, decides what to do:
//   the recorded nonce, agent on the books -> the site's own same-document rewrite: nothing;
//   the recorded nonce, no agent           -> the announced document finished loading: arm;
//   a nonce not yet recorded               -> a document whose announcement is late or was lost
//                                            (a worker woken late, a tab claimed after its
//                                            document_start): reset + arm, once — the announcement
//                                            that lands afterwards carries the same nonce;
//   no answer                              -> no content script here: reset + arm (the inject then
//                                            fails fast and the inject-fail ladder reloads the tab).
// Arming straight from 'complete' was tried first: with a late announcement it armed twice — the
// announcement reset the generation the 'complete' arm had just published — one wasted upgrade
// and a false external-reload count per occurrence.
function reconcileDocument(sid, t, tabId) {
  chrome.tabs.sendMessage(tabId, { cmd: 'announce' }).then((r) => {
    if (searchTabs.get(sid) !== t || t.tabId !== tabId) return;
    const nonce = (r && typeof r.doc === 'string') ? r.doc : '';
    if (nonce && nonce !== t.docNonce) { t.docNonce = nonce; documentReplaced(t); }
    if (!t.injected && !t.arming) armAgent(sid, t, 'page load');
  }, () => {
    if (searchTabs.get(sid) !== t || t.tabId !== tabId) return;
    documentReplaced(t);
    armAgent(sid, t, 'page load');
  });
}
// The announcement can land after the load has already completed (a fast cached load, a worker
// woken late): then the 'complete' handler saw `injected` still true and armed nothing.
function armIfComplete(sid, t) {
  if (t.tabId == null) return;
  chrome.tabs.get(t.tabId).then((tab) => {
    if (searchTabs.get(sid) !== t || !tab || tab.status !== 'complete') return;
    if (!t.injected && !t.arming) armAgent(sid, t, 'page load');
  }).catch(() => {});
}
// Refusals used to be silent — the incident above read as "Linking… forever" with a clean log, and
// the agent's own drop line pointed at a "claim-denied line" that never existed. One line per
// search per reason per 30 s.
const refusalLogAt = new Map();
function logRefusal(sid, what) {
  const key = String(sid) + '|' + what.slice(0, 40);
  const now = Date.now();
  if (now - (refusalLogAt.get(key) || 0) < 30000) return;
  refusalLogAt.set(key, now);
  log(`Live search ${String(sid).slice(0, 8)}…: ${what}`);
}

// === Which tab is mine? ==========================================================================
// The tab URL cannot answer that for a 0.5.5 search (the site re-spells the id right after every
// load, and two searches in one league then look alike), so the tab id we opened or adopted for a
// search is remembered in chrome.storage.local: it survives a worker restart (the common case),
// an extension update (which orphans the old content scripts — the agent in that tab has to be
// replaced by a reload, so the tab must be found) and a browser restart. A tab id is meaningful only
// inside one browser session, so a remembered id is trusted only once the tab it names is confirmed
// to be a pinned tab on this search's page; a restored session's tabs come back DISCARDED under new
// ids and are adopted by page instead (nothing can be running in a discarded tab).
async function loadTabRegistry() {
  try { const v = await chrome.storage.local.get('searchTabs'); return (v && v.searchTabs && typeof v.searchTabs === 'object') ? v.searchTabs : {}; }
  catch (e) { return {}; }
}
function saveTabRegistry() {
  const reg = {};
  for (const [sid, t] of searchTabs.entries()) if (t.tabId != null) reg[sid] = t.tabId;
  try { const p = chrome.storage.local.set({ searchTabs: reg }); if (p && typeof p.catch === 'function') p.catch(() => {}); } catch (e) {}
}
const reservedTabIds = new Set();   // adopted in the same turn the tabs.query answered, before t.tabId is assigned
const closingTabIds = new Set();    // removal in flight (a search edit closes X and opens Y in one config push)
// Tab ids are reassigned by every browser session: an id remembered before a crash or a kill can name
// an unrelated pinned tab afterwards (Firefox numbers from 1 each time). The registry is therefore
// dropped at profile start — a restored session is adopted by page (tier 3), never by id.
try { chrome.runtime.onStartup.addListener(() => { try { const p = chrome.storage.local.remove('searchTabs'); if (p && typeof p.catch === 'function') p.catch(() => {}); } catch (e) {} }); } catch (e) {}

// Live-search reconnect backoff. A healthy live WS stays open for a long time; GGG's rate-limit
// reject (close 1013) hangs up within ~1s of opening. So we measure how long each socket stayed
// open: a sub-HEALTHY_OPEN_MS close counts as a failed attempt and the per-search reconnect delay
// grows exponentially (with jitter, so many searches don't resync into a thundering herd). This
// stops the flat-5s re-inject storm from keeping GGG's rate limit permanently hot — it mirrors the
// native tls-client path's escalating 1013 backoff.
const RECONNECT_BASE_MS = 5000;
const RECONNECT_MAX_MS = 300000;   // cap one search's reconnect gap at 5 min
const HEALTHY_OPEN_MS = 15000;     // WS open >= this before closing = a real session (reset backoff)

// Randomized in-page channel token (anti-fingerprint): wraps every window.postMessage between the
// MAIN-world agents and content.js so the page sees no fixed pfx/pfxctl markers. Persisted in
// storage.session so it survives a service-worker restart, and is never exposed to web pages.
let CH = null;
async function ensureCh() {
  if (CH) return CH;
  try { const g = await chrome.storage.session.get('ch'); if (g && g.ch) CH = g.ch; } catch (e) {}
  if (!CH) {
    CH = (self.crypto && crypto.randomUUID) ? crypto.randomUUID() : ('c' + Math.random().toString(36).slice(2) + Date.now().toString(36));
    try { await chrome.storage.session.set({ ch: CH }); } catch (e) {}
  }
  return CH;
}

// Manual (one-shot bulk) buy. The loop is SW-OWNED (runManualBuy): the temp tab is only a network
// executor for short MAIN-world bursts, so Edge throttling/freezing/sleeping the background tab can't
// strand it — the silent "stops buying after N items" bug.
let manualBuy = null;   // { id, search, itemCount, tabId, started, cancelled, counts, buyResolve, buyTimer }
function mbCounts(extra) { const c = manualBuy ? manualBuy.counts : { processed:0,bought:0,failed:0,unknown:0,skipped:0,total:0 }; return Object.assign({}, c, extra || {}); }
function mbStatus(state, extra) { if (ptbp && manualBuy) ptbp.sendManualBuyStatus(manualBuy.id, state, mbCounts(extra)); }

async function startManualBuy(m) {
  if (manualBuy) { if (ptbp) ptbp.sendManualBuyStatus(m.id, 'error', { detail: 'another bulk buy is running' }); return; }
  const search = Object.assign({}, m.search || {});
  search.filters = m.filters || {};   // host sends filters as a top-level sibling of `search`
  manualBuy = { id: m.id, search, itemCount: m.itemCount | 0, tabId: null, started: false, cancelled: false,
                counts: { processed: 0, bought: 0, failed: 0, unknown: 0, skipped: 0, total: m.itemCount | 0 }, buyResolve: null, buyTimer: null };
  mbStatus('started');
  try {
    const tab = await chrome.tabs.create({ url: searchPageUrl({ realm: search.realm, league: search.league, searchId: search.searchId, domain: search.domain }), active: false, pinned: true });
    manualBuy.tabId = tab.id;
    // Keep this background tab loaded; the SW injects only short network bursts into it.
    try { await chrome.tabs.update(tab.id, { autoDiscardable: false }); } catch (e) {}
    log(`Manual buy: opened tab for ${search.note || search.searchId}`);
  } catch (e) {
    mbStatus('error', { detail: 'open tab failed: ' + e.message }); manualBuy = null;
  }
}

function cancelManualBuy(id) {
  if (!manualBuy || (id && manualBuy.id !== id)) return;
  log(`Manual buy: cancel requested (${manualBuy.id})`);
  manualBuy.cancelled = true;
  // Wake a pending buy_result wait so the loop exits at once instead of sitting out the safety timeout.
  if (manualBuy.buyResolve) { const f = manualBuy.buyResolve; manualBuy.buyResolve = null; if (manualBuy.buyTimer) { clearTimeout(manualBuy.buyTimer); manualBuy.buyTimer = null; } f(null); }
  // Closing the tab kills any in-flight executeScript; an in-game buy already handed to the host
  // finishes independently. This only stops FUTURE whispers — exactly cancel intent.
  finishManualBuy('cancelled', { detail: 'user cancelled' });
}

async function finishManualBuy(state, extra) {
  if (!manualBuy) return;
  if (manualBuy.buyTimer) { clearTimeout(manualBuy.buyTimer); manualBuy.buyTimer = null; }
  mbStatus(state, extra);
  const t = manualBuy.tabId; manualBuy = null;
  if (t != null) { closingTabIds.add(t); try { await chrome.tabs.remove(t); } catch (e) {} closingTabIds.delete(t); }
}

// Wait (in the SW) for the host's buy_result for the group just handed over. Resolved by onBuyResult;
// a safety timeout (> host BUSY_SAFETY_MS) prevents a permanent hang if a result never arrives.
function awaitBuyResult() {
  return new Promise((resolve) => {
    if (!manualBuy) { resolve(null); return; }
    manualBuy.buyResolve = resolve;
    manualBuy.buyTimer = setTimeout(() => {
      if (manualBuy && manualBuy.buyResolve) { const f = manualBuy.buyResolve; manualBuy.buyResolve = null; manualBuy.buyTimer = null; log('Manual buy: buy_result timeout (185s) — continuing'); f(null); }
    }, 185000);
  });
}

// SW-OWNED bulk-buy loop. The tab runs only short MAIN-world bursts: search/pick once, then one
// whisper per seller. Each buy_result is awaited HERE in the service worker (which never sleeps), so
// nothing long-lived runs in the throttle-prone background tab. One buy at a time via the shared latch.
async function runManualBuy(tabId) {
  if (!manualBuy || manualBuy.tabId !== tabId) return;
  const myId = manualBuy.id;
  const host = hostFor(manualBuy.search.realm, manualBuy.search.domain);
  const poe2 = !!(manualBuy.search.realm && String(manualBuy.search.realm).length);   // non-empty realm ⇒ PoE2
  const exec = async (func, args) => { const res = await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func, args }); return (res && res[0]) ? res[0].result : null; };
  const alive = () => !!manualBuy && manualBuy.id === myId && !manualBuy.cancelled;
  const sleep = (ms) => new Promise(r => setTimeout(r, ms));
  const want = manualBuy.itemCount | 0;
  const infinite = want <= 0;       // count 0 = keep re-searching + buying until the user cancels
  const seen = new Set();           // listing ids already attempted (infinite: act only on NEW listings)
  let bought = 0, failed = 0, unknown = 0, skipped = 0;
  const processed = () => bought + failed + unknown + skipped;
  const bump = () => { if (alive()) { manualBuy.counts = { processed: processed(), bought, failed, unknown, skipped, total: infinite ? processed() : (manualBuy.counts.total || want) }; mbStatus('progress'); } };
  // Rate-limit pause state is SW-SCOPE: the in-page rateUntil dies with each executeScript burst,
  // so without this a penalty learned one burst ago was forgotten by the next. A stated penalty is
  // honoured IN FULL — every request made inside it refreshes it (the old ≤30 s nibble is how one
  // 429 grew into a 1706 s ban) — and it is honoured unconditionally, like the host's httpGet:
  // the rateLimit behavior flag governs soft pacing only, never a penalty the site has stated.
  let rateUntil = 0;
  let whisperRl = 0;                // consecutive rate-limited whisper attempts (current group)
  let burstRl = 0;                  // consecutive rate-limited fetch bursts
  const rateWait = async (ms, why, attempt) => {
    const wait = clampMbRateWait(ms);
    rateUntil = Date.now() + wait;
    const sec = Math.ceil(wait / 1000);
    const nth = (attempt | 0) > 1 ? `, attempt ${attempt}` : '';
    // Say WHOSE limit this is: the field reads a bare "rate limited — pausing" as the program
    // being broken and cancels mid-wait (log 2026-08-05: three manual-buy runs cancelled inside
    // the pause, "manual buy doesn't work at all"). It is the trade site's account-wide budget;
    // sitting it out is the only cure.
    log(`Manual buy: the trade site rate-limited this account (${why}${nth}) — waiting ${sec}s; the limit clears on its own, cancelling will not speed it up`);
    mbStatus('progress', { detail: 'site rate limit — waiting ' + sec + 's' });
    while (alive() && Date.now() < rateUntil) await sleep(Math.min(1000, Math.max(50, rateUntil - Date.now())));
    return alive();
  };
  try {
    const B = hostBehavior;
    // for(;;) rather than do/while: `continue` must restart the PASS (a count-mode run retries a
    // rate-limited burst too) — in a do/while `continue` jumps to the condition and a count-mode
    // retry would silently end the run instead.
    for (;;) {
      if (!alive()) return;
      // Not-in-game gate (Task 11; mirrors the live onListing drop + trade.js ingameAllowed): wait in place
      // before spending any network/latch. Applies to BOTH infinite and count mode so a not-in-game manual
      // buy never fetches, whispers, or burns its budget as "failed" (and never re-search-spins while gated).
      // Reads hostBehavior LIVE (not the loop-start snapshot B) so a mid-run config push takes effect at once.
      if (hostBehavior.ingame === false) {
        let shownReason = pauseReasonText(hostBehavior);
        log('Manual buy: paused (' + shownReason + ')');
        while (hostBehavior.ingame === false && alive()) {
          await sleep(3000);
          // The CAUSE can change while the gate stays shut — an auto-stash trip that ends in a
          // safety stop is the field case. The host re-pushes on a reason change, so reprint when
          // the text moves; only when it moves, because this wait can run for minutes.
          const nowReason = pauseReasonText(hostBehavior);
          if (hostBehavior.ingame === false && nowReason !== shownReason) {
            shownReason = nowReason;
            log('Manual buy: still paused (' + shownReason + ')');
          }
        }
        if (!alive()) return;
        log('Manual buy: resumed (in game)');
      }
      // Carry-over penalty gate: a stated wait learned last pass is an ABSOLUTE barrier for the
      // next network burst — the same rule the live path applies to nextInjectAt.
      if (rateUntil > Date.now()) { if (!(await rateWait(rateUntil - Date.now(), 'carry-over'))) return; }
      // 1) resolve + fetch + pick the cheapest matching listings (one network burst in the page).
      // Count mode asks only for what is still OWED: a penalty-cut pass re-runs (below), and the
      // re-run must not overshoot the user's count with what earlier passes already processed.
      const remaining = infinite ? 0 : Math.max(0, want - processed());
      const batchFetchAt = performance.now();
      const pick = await exec(pfxMbFetchPick, [host, manualBuy.search.realm, manualBuy.search.league, manualBuy.search.searchId, remaining, manualBuy.search.filters || {}]);
      const batchReadyAt = performance.now();
      if (!alive()) return;
      if (!pick || pick.error) {
        const rl = decideMbRate((pick && pick.rateMs) || 0, ++burstRl);
        if (rl.action !== 'none') {
          // Rate-limited burst: sit the FULL penalty out, then re-run the search — in BOTH modes.
          // Count mode used to end the whole run with 'error' here, which read as "buying just
          // stopped"; a stated penalty is transient by definition (the site names its end).
          // The wait ESCALATES with consecutive limited bursts (escalateMbWait): each retry
          // re-runs resolve+POST+fetch, and at a 10 s hint's cadence that drumbeat alone kept a
          // saturated long window pinned (field log 2026-08-05).
          if (!(await rateWait(escalateMbWait((pick && pick.rateMs) || 0, burstRl), 'search/fetch', burstRl))) return;
          if (infinite || rl.action === 'retry') continue;
          finishManualBuy('error', { detail: 'rate limited ' + burstRl + 'x on search — giving up' }); return;
        }
        burstRl = 0;
        if (infinite) { await sleep(8000); continue; }   // transient → re-search
        finishManualBuy('error', { detail: (pick && pick.error) || 'fetch failed' }); return;
      }
      // Filter attempted listings in BOTH modes: a penalty-cut count pass re-runs, and the re-run
      // must not re-whisper what an earlier pass already handed to the host.
      let picked = (pick.picked || []).filter(it => !seen.has(it.itemId));
      if (!infinite && processed() === 0) { manualBuy.counts.total = pick.budget || picked.length; mbStatus('progress'); }
      // The burst can return listings AND a penalty (it stops at the first 429/in-band limit but
      // keeps what it picked). Pause BEFORE whispering — whispering inside the penalty is exactly
      // the request that keeps refreshing it. The wait escalates with consecutive limited bursts
      // (escalateMbWait — same rationale as the search/fetch path above).
      if (pick.rateMs > 0) {
        const rl = decideMbRate(pick.rateMs, ++burstRl);
        if (!(await rateWait(escalateMbWait(pick.rateMs, burstRl), 'fetch burst', burstRl))) return;
        if (picked.length < (pick.budget || 0)) {
          // The penalty cut the burst short of its budget: whatever it did not fetch is still
          // OWED. Re-run the pass — the old flow whispered the fetched subset and then ended a
          // count run as a false 'done' with the remainder never attempted (review 2026-08-02).
          if (!infinite && rl.action === 'fail') {
            finishManualBuy('error', { detail: 'rate limited ' + burstRl + 'x on fetch — giving up' }); return;
          }
          continue;
        }
      }
      burstRl = 0;
      if (!picked.length) {
        // Nothing new to buy right now: poll the search again, but gently — re-searching is the main
        // rate-limit cost when idle, so back off well clear of GGG's window.
        if (infinite) { await sleep(12000); continue; }
        finishManualBuy('done', { detail: 'no matching items' }); return;
      }
      const groups = groupBySeller(picked);
      log(`Manual buy: ${picked.length} item(s) in ${groups.length} group(s)${infinite ? ' (infinite)' : ''}`);
      for (let gi = 0; gi < groups.length; gi++) {
        if (!alive()) return;
        const g = groups[gi], first = g.items[0], n = g.items.length;
        // This runs only after the preceding awaitBuyResult() has completed, so
        // the previous item's auto-stash/return-home tail is outside this cycle.
        const timingDraft = createTimingDraft('extension_manual');
        addMeasuredStage(timingDraft, 'listing_fetch', batchFetchAt, batchReadyAt);
        const sourceQueueAt = performance.now();
        // claim the shared latch (serialises with live searches); wait up to 120s for the host to be ready
        let granted = false; const dl = Date.now() + 120000;
        while (!granted && alive() && Date.now() < dl) { granted = tryClaim(myId); if (!granted) await sleep(700); }
        if (!alive()) { if (granted) clearBusy('mb-cancel'); return; }
        // whisperRl is "consecutive rate-limited attempts for the CURRENT group": every exit that
        // abandons the group must reset it, or the NEXT group inherits the streak and gets written
        // off after fewer than streakMax attempts (review 2026-08-02).
        if (!granted) { whisperRl = 0; failed += n; bump(); continue; }
        // Not-in-game gate (Task 11; mirrors trade.js ingameAllowed): the flag can flip false between the
        // batch fetch and this group (a mid-run config push). Free the latch and SKIP the group WITHOUT
        // counting it failed or adding it to `seen` — a never-attempted listing must stay eligible for the
        // next re-search rather than be blacklisted or burn the count budget. Reads hostBehavior LIVE.
        if (hostBehavior.ingame === false) {
          log('Manual buy: whisper skipped (' + pauseReasonText(hostBehavior) + ')');
          whisperRl = 0;   // group abandoned — the streak must not leak to the next one
          clearBusy('mb-not-ingame');
          continue;
        }
        // Host-not-ready re-check (2026-08-03): `ready` folds the host's busy in, and busy
        // now covers its auto-stash dump — it can flip false between the claim-grant above
        // and this whisper. A whisper is a teleport; instead of firing it into the dump,
        // free the latch and RE-RUN this same group through the claim wait (which polls
        // hostReady up to 120s — the "wait the dump out, then buy" the user asked for).
        // The listings are not in `seen` yet, so nothing is lost if the claim then fails.
        if (!hostReady) {
          log('Manual buy: host busy (stash dump in progress?) — waiting it out before the whisper');
          clearBusy('mb-host-not-ready');
          gi--;
          continue;
        }
        const wireGroup = { searchId: manualBuy.search.searchId,
          groupId: manualBuy.search.searchId + '-' + first.itemId,
          isLastGroup: false, items: g.items };
        let prepareId = '';
        if (n >= 2 && hostBehavior.packetBatch) {
          try {
            const ready = ptbp ? await ptbp.prepareBuy(wireGroup, 'manual') : null;
            prepareId = ready && ready.id ? ready.id : '';
            if (!prepareId) throw new Error('host did not return a prepare id');
          } catch (e) {
            log(`Manual buy: seller batch prepare failed (${(e && (e.code || e.message)) || 'unknown'})`);
            clearBusy('mb-prepare-failed');
            whisperRl = 0; failed += n; bump();
            continue;
          }
          if (!alive()) { if (ptbp) ptbp.cancelPrepared(prepareId, 'manual_cancelled'); clearBusy('mb-cancel'); return; }
        }
        for (const it of g.items) seen.add(it.itemId);   // attempted → a re-search won't re-whisper it
        // whisper (short burst in the page); the host processes the whole group. Force-teleport
        // applies to both games (v1.3.0); the "in demand" retry does too (2026-07-31) — ONE
        // immediate re-send carrying continue:true, the site's own "whisper again" click.
        // The retry's answer is final.
        const whisperAt = performance.now();
        addMeasuredStage(timingDraft, 'source_queue', sourceQueueAt, whisperAt);
        let retriedInDemand = false;
        let w = null; try { w = await exec(pfxMbWhisper, [host, first.hideoutToken, poe2, !!hostBehavior.forceTeleport]); } catch (e) { w = null; }
        if (w && !w.ok && w.inDemand && hostBehavior.inDemandRetry) {
          retriedInDemand = true;
          if (ptbp) ptbp.sendTradeEvent({ stage: 'whisper', outcome: 'in_demand', itemId: first.itemId, item: first });
          try { w = await exec(pfxMbWhisper, [host, first.hideoutToken, poe2, true, true]); } catch (e) { w = null; }
        }
        const whisperDoneAt = performance.now();
        if (!alive()) { if (prepareId && ptbp) ptbp.cancelPrepared(prepareId, 'manual_cancelled'); clearBusy('mb-cancel'); return; }
        if (!w || !w.ok) {
          addMeasuredStage(timingDraft, 'whisper', whisperAt, whisperDoneAt,
                           (w && w.inDemand) ? 'degraded' : 'failed');
          if (ptbp) ptbp.sendTradeEvent({ stage: 'whisper', outcome: (w && w.inDemand) ? 'teleport_failed' : 'whisper_failed', itemId: first.itemId, item: first, detail: String(w ? w.status : 0) + (w && w.msg ? (' ' + w.msg) : ''), timing: finalizeTiming(timingDraft) });
          if (prepareId && ptbp) ptbp.cancelPrepared(prepareId, 'whisper_failed');
          clearBusy('mb-whisper-failed');
          const rl = decideMbRate((w && w.rateMs) || 0, ++whisperRl);
          if (rl.action === 'retry') {
            // Rate limited: this group was never actually whispered. Sit the FULL stated penalty
            // out (the old ≤30 s nibble refreshed it on every next whisper), un-mark the listings
            // so the group stays eligible, and retry the SAME group — not the next seller.
            for (const it of g.items) seen.delete(it.itemId);
            if (!(await rateWait(rl.waitMs, 'whisper', whisperRl))) return;
            gi--;
            continue;
          }
          whisperRl = 0; failed += n; bump();
          if (rl.action === 'fail') {
            // Still limited after streakMax full waits: give this group up, but the penalty gates
            // the NEXT request all the same — wait before touching the next seller.
            if (!(await rateWait(rl.waitMs, 'whisper (giving up on group)', whisperRl))) return;
          }
          continue;
        }
        whisperRl = 0;
        addMeasuredStage(timingDraft, 'whisper', whisperAt, whisperDoneAt,
                         retriedInDemand ? 'degraded' : 'ok');
        const bridgeDoneAt = performance.now();
        addMeasuredStage(timingDraft, 'bridge_queue', whisperDoneAt, bridgeDoneAt);
        wireGroup.timing = finalizeTiming(timingDraft);
        const rid = ptbp ? ptbp.sendBuyRequest(wireGroup, prepareId) : null;
        log(`Sent buy ${rid} (${first.seller || '?'})`);
        const result = await awaitBuyResult();   // host clears the latch on buy_result
        if (!alive()) return;
        const summary = result && result.summary;
        if (summary) {
          let left = n;
          const take = (value) => { const amount = Math.min(left, Math.max(0, value | 0)); left -= amount; return amount; };
          bought += take(summary.bought); failed += take(summary.failed);
          unknown += take(summary.unknown); skipped += take(summary.skipped);
          unknown += left; // malformed/incomplete summary remains explicit, never guessed Bought
        } else {
          // No result is not evidence of a purchase. Keep it explicit for reconciliation.
          unknown += n;
        }
        bump();
      }
      if (seen.size > 8000) seen.clear();          // bound memory on a long infinite run
      if (!(infinite && alive())) break;
      await sleep(3000);                           // gap before re-polling the search snapshot
    }
    finishManualBuy('done', { processed: processed(), bought, failed, unknown, skipped, total: infinite ? processed() : (manualBuy.counts.total || want) });
  } catch (e) {
    if (alive()) finishManualBuy('error', { detail: (e && e.message) || 'loop error' });
  }
}

let busy = false;            // a purchase pipeline is in flight (global, cross-tab)
let busyHolder = null;       // searchId holding the latch (for logging)
let busyTimer = null;        // safety force-release
const BUSY_SAFETY_MS = 180000;
function clearBusy(why) {
  if (!busy) return;
  busy = false; busyHolder = null;
  if (busyTimer) { clearTimeout(busyTimer); busyTimer = null; }
  log(`Buy latch released (${why})`);
}
let lastDenyLogAt = 0;        // throttle deny logs (manual-buy polls tryClaim every 700ms)
function tryClaim(sid) {
  const { grant } = { grant: hostReady && !busy };   // mirrors trade.js decideClaim
  if (grant) {
    busy = true; busyHolder = sid;
    if (busyTimer) clearTimeout(busyTimer);
    busyTimer = setTimeout(() => { log('Buy latch force-released (no result)'); clearBusy('safety'); }, BUSY_SAFETY_MS);
  } else if (Date.now() - lastDenyLogAt > 5000) {
    lastDenyLogAt = Date.now();
    log(`Claim denied for ${String(sid).slice(0, 8)}… (${!hostReady ? 'host not ready' : `buy latch held by ${busyHolder || '?'}`})`);
  }
  return grant;
}

function log(msg) {
  logBuf.unshift({ t: Date.now(), msg }); if (logBuf.length > 100) logBuf.pop();
  if (ptbp && ptbp.connected) ptbp.sendLog('info', msg);   // all extension logs -> POEFixer
}

// NOTE (Firefox): the agent below is injected with `world: 'MAIN'`, which Firefox only supports
// from 128 — hence `strict_min_version: "128.0"` in manifest.firefox.json. On 121–127 every inject
// rejects, and with the supervisor in place that would become a tab reloading itself every couple
// of minutes instead of one silent failure.
// ===== MAIN-world agent (runs entirely in the page: real Origin/Referer/cookies). =====
// Self-contained (no imports, no chrome.*). Communicates via window.postMessage.
// PoE1 live WS: {"auth":true} first, then EITHER {"new":["id",…]} per burst (legacy
// shape) OR {"result":"<JWT>"} per listing — the current unified live backend pushes
// the PoE2-style short-lived JWT (~20s exp), which goes in the fetch path VERBATIM:
// /trade/fetch/<JWT>?query=<searchId> (live-confirmed 2026-07-13). Legacy id bursts
// fetch via /trade/fetch/<ids> (≤10, no realm). Whisper via /trade/whisper with
// listing.whisper_token — it messages the seller (NO teleport).
// MIRROR CONTRACT: this agent (and pfxMbFetchPick/pfxMbWhisper below) inlines near-copies of the
// fetch/whisper/parse logic from trade.js, because executeScript(world:'MAIN') cannot import
// modules. trade.js is the TESTED reference (tests/trade.test.mjs) — when changing behavior in
// either place, port the change to the other.
function pfxLiveAgent(liveUrl, searchId, realm, league, behaviorInit, filtersInit, ch, gen, tune) {
  const W = window;
  const T = tune || {};
  // --- late-arrival guards, FIRST -----------------------------------------------------------------
  // executeScript against a frozen tab is queued, not failed, so this function can run long after
  // it was issued — even in a DIFFERENT document, if the supervisor replaced the wedged one.
  // Guard 1, AGE: landing ≥ stuckMs after issue means the service worker long gave up on this
  // inject (its race times out at 10 s; the injectStuck reload fires at 30 s) — and a replaced
  // document carries no generation to compare against, so age is the only guard that works there.
  // Opening a socket here would bypass the fleet upgrade gate entirely (review 2026-07-30).
  try { if (T.issuedAt && (Date.now() - T.issuedAt) >= (T.stuckMs || 30000)) return; } catch (e) {}
  // --- generation guard ---------------------------------------------------------------------------
  // The background re-arms a search whenever it looks dead (tab discarded or reloaded, heartbeats
  // stopped, socket closed), so injection has to be idempotent: the newest generation owns the
  // document, the previous one's socket is closed right here, and every callback of an older
  // generation stands down at `mine()`. Two live agents in one document = two whispers for one
  // listing. The key is derived from the random per-session channel token, so it adds no fixed
  // marker for the page to fingerprint.
  const K = '__' + ch;
  // Guard 2, ORDER: "last to run wins" would be exactly backwards for queued injects — the stale
  // agent would stamp its old generation over the live one, tear the live agent down and open one
  // more socket. Generations are monotonic numbers; yield to any equal-or-newer generation on the
  // page. MIRROR of trade.js agentShouldYield (tested reference).
  try { const cur = W[K]; if (typeof cur === 'number' && typeof gen === 'number' && cur >= gen) return; } catch (e) {}
  // Tear the previous generation down through the thunk IT published: its socket and its listeners
  // go together, and nothing but a closure is left on the page. Both properties are defined
  // non-enumerable and hold no WebSocket — `Object.keys(window)` shows nothing, and the page cannot
  // reach the live socket to read its URL or close it.
  try { const prevStop = W[K + 'x']; if (typeof prevStop === 'function') prevStop(); } catch (e) {}
  const defineHidden = (key, value) => {
    try { Object.defineProperty(W, key, { value, writable: true, configurable: true, enumerable: false }); }
    catch (e) { W[key] = value; }
  };
  defineHidden(K, gen);
  const listeners = new AbortController();
  const mine = () => W[K] === gen;
  const BEAT_MS = T.beatMs || 20000;
  const DEAD_MS = T.deadMs || 150000;
  const S = { behavior: behaviorInit || { forceTeleport: false, inDemandRetry: true, rateLimit: true, ingame: true, packetBatch: false, pauseReason: '' }, filters: filtersInit || {}, ready: false, inFlight: false, inFlightAt: 0, rateUntil: 0, ws: null, claimWaiter: null, prepareWaiter: null, prepareSeq: 0, activePrepareId: '', whisperStarted: false, lastMsgAt: Date.now(), openedAt: Date.now(), lastBeatRunAt: Date.now(), beatTimer: null };
  // MIRROR of trade.js pauseReasonText (the tested reference): an agent injected with
  // world:'MAIN' is serialised by .toString() and cannot import a module, so the map lives twice.
  // Port every change to both — the same rule as the fetch/whisper/parse mirrors above.
  const pauseText = () => {
    const raw = (S.behavior && typeof S.behavior.pauseReason === 'string') ? S.behavior.pauseReason : '';
    if (!raw) return 'not in game';
    const cut = raw.indexOf(':');
    const head = (cut < 0 ? raw : raw.slice(0, cut)).slice(0, 60);
    const tail = (cut < 0 ? '' : raw.slice(cut + 1)).slice(0, 60);
    const map = { not_in_game: 'not in game', no_session: 'no trade session', stash_busy: 'stash busy',
                  safety_stop: 'safety stop', afk_recovery: 'AFK recovery', shutdown: 'host shutting down',
                  paused: 'paused by hotkey', stopped: 'trading stopped' };
    const text = map[head] || head.replace(/_/g, ' ') || 'not in game';
    return tail ? text + ': ' + tail.replace(/_/g, ' ') : text;
  };
  let cancelOnStop = () => {};
  const stop = () => {
    try { cancelOnStop(); } catch (e) {}
    if (S.prepareWaiter) { const w = S.prepareWaiter; S.prepareWaiter = null; try { w.resolve({ ready: false, error: 'agent_superseded' }); } catch (e) {} }
    try { listeners.abort(); } catch (e) {}
    try { clearInterval(S.beatTimer); } catch (e) {}
    try { if (S.ws && S.ws.readyState <= 1) S.ws.close(); } catch (e) {}
  };
  defineHidden(K + 'x', stop);
  const HOST = location.host;
  // Unified routing: a non-empty realm ⇒ PoE2 (/api/trade2 + /<realm>/ + &realm=); empty ⇒ PoE1 (/api/trade).
  const poe2 = !!(realm && String(realm).length);
  // A superseded agent stays silent — EXCEPT for messages that REPORT an action it has
  // already committed. Its whisper has been sent (the player is being teleported): swallowing the
  // `buy` would leave them in the seller's hideout with nothing bought, and swallowing the `release`
  // would hold the global buy latch until the 180 s safety net, making every search deaf meanwhile.
  // Neither can start anything: `release` is checked against the latch holder, and a `buy` only
  // exists after a whisper the server accepted.
  const postCommit = (t) => t === 'buy' || t === 'release' || t === 'tradeevent' || t === 'cancelPrepare';
  const out = (o) => { if (!mine() && !postCommit(o && o.t)) return; W.postMessage({ [ch]: Object.assign({ sid: searchId, g: gen }, o) }, location.origin); };
  const cancelPrepare = (prepareId, reason) => {
    if (!prepareId) return;
    out({ t: 'cancelPrepare', prepareId, reason: reason || 'cancelled' });
    if (S.activePrepareId === prepareId) S.activePrepareId = '';
  };
  cancelOnStop = () => {
    // Once the whisper request has started it cannot be recalled.  Its completion path owns the
    // cancel-or-buy decision even if a newer generation has replaced this agent meanwhile.
    if (S.activePrepareId && !S.whisperStarted) cancelPrepare(S.activePrepareId, 'agent_superseded');
  };
  const addRawStage = (draft, key, startMs, endMs, outcome) => {
    draft.stages.push({ key, startMs, endMs, outcome: outcome || 'ok' });
  };
  const furl = (path) => poe2
    ? ('https://' + HOST + '/api/trade2/fetch/' + path + '?query=' + encodeURIComponent(searchId) + '&realm=' + realm)
    : ('https://' + HOST + '/api/trade/fetch/' + path + '?query=' + encodeURIComponent(searchId));
  // Ask the background arbiter for the global buy latch (resolves to true/false).
  // The 4 s failsafe may cancel ONLY ITS OWN waiter (=== me). It used to check bare truthiness,
  // so the stale timer of an already-answered claim disarmed the NEXT claim's failsafe — and when
  // that claim's grant reply was lost in the relay (it races the previous buy's buy_result),
  // `await claim()` hung forever with S.inFlight stuck true: every later listing dropped as
  // "previous fetch still in flight" until the user reconnected the search (field log 2026-08-05,
  // 5.5 min of drops after 33 good buys). Pinned in tests/liveagent-claim.test.mjs.
  const claim = () => new Promise((res) => {
    const me = res;
    S.claimWaiter = me;
    S.claimDenied = '';
    out({ t: 'claim' });
    setTimeout(() => { if (S.claimWaiter === me) { S.claimWaiter = null; S.claimDenied = 'no answer from the extension within 4 s'; me(false); } }, 4000);
  });
  const prepare = (group) => new Promise((resolve) => {
    const key = String(gen) + '-' + (++S.prepareSeq) + '-' + Date.now().toString(36);
    const waiter = { key, resolve };
    S.prepareWaiter = waiter;
    out({ t: 'prepare', key, origin: 'live', group });
    setTimeout(() => {
      if (S.prepareWaiter === waiter) {
        S.prepareWaiter = null;
        resolve({ ready: false, error: 'prepare_relay_timeout' });
      }
    }, 6500);
  });
  const release = () => { out({ t: 'release' }); S.inFlight = false; };
  // Bound every network call (same rationale as the manual-buy agent): a credentialed fetch can
  // hang indefinitely and would otherwise leave S.inFlight stuck → every later listing dropped.
  const FETCH_TIMEOUT_MS = 15000;
  const fetchT = async (url, opts) => {
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), FETCH_TIMEOUT_MS);
    try { return await fetch(url, Object.assign({ signal: ctl.signal }, opts || {})); }
    finally { clearTimeout(t); }
  };
  async function getJson(path) {
    // MIRROR of trade.js JSON_GET_HEADERS — read the contract there. Inlined because this agent is
    // serialised by toString() into the page and cannot import. All three names matter: `fetch`
    // never adds X-Requested-With on its own, and the site sets a bare `en-US` on this endpoint
    // (not on the POST). Do not copy Accept-Language onto the whisper below.
    const r = await fetchT(furl(path), { credentials: 'include', headers: { 'Accept': 'application/json', 'Accept-Language': 'en-US', 'X-Requested-With': 'XMLHttpRequest' } });
    if (r.status === 429) { const ra = r.headers.get('Retry-After'); S.rateUntil = Date.now() + (ra ? (parseInt(ra, 10) || 5) : 10) * 1000; }
    if (!r.ok) throw new Error('fetch ' + r.status);
    return r.json();
  }
  async function whisper(token, force, retry) {
    // MIRROR of trade.js whisperBody: force-teleport adds `continue:'true'` (STRING) for BOTH
    // games since v1.3.0. The in-demand RETRY runs on both games too (2026-07-31) and POSTs
    // `continue:true` — a BOOLEAN, the site's own "whisper again" click; retry wins over force.
    // Do not merge the two wire shapes.
    const body = retry ? { token, continue: true }
                       : (force ? { token, continue: 'true' } : { token });
    let r;
    try {
      r = await fetchT('https://' + HOST + '/api/' + (poe2 ? 'trade2' : 'trade') + '/whisper', {
        method: 'POST', credentials: 'include',
        headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest', 'Accept': '*/*' },
        body: JSON.stringify(body)
      });
    } catch (e) {
      // Timeout / network drop — treat as a failed whisper so processOne frees the latch.
      return { ok: false, inDemand: false, status: 0 };
    }
    if (r.status === 429) { const ra = r.headers.get('Retry-After'); S.rateUntil = Date.now() + (ra ? (parseInt(ra, 10) || 5) : 10) * 1000; }
    let b = {}; try { b = await r.json(); } catch (e) {}
    // Surface the server's own explanation (e.g. league/character requirements) —
    // a bare "400" is undiagnosable.
    const msg = (b && b.error) ? String(b.error.message || b.error.code || '') : '';
    // BOTH games: success:false with NO error => item "in demand" (another buyer whispered
    // first). The old PoE1 exclusion was an assumption, disproven 2026-07-31.
    const inDemand = !!(b && b.success === false && !b.error);
    return { ok: r.ok && b && b.success === true, inDemand, status: r.status, msg };
  }
  // explicitMods can come back as {description,...} objects (search w/ explicit stat filters);
  // implicitMods stay strings. Flatten both to the readable line for the host + Trade Logs.
  const modLine = (m) => (typeof m === 'string') ? m : ((m && typeof m.description === 'string') ? m.description : '');
  const normMods = (a) => Array.isArray(a) ? a.map(modLine).filter(s => s) : [];
  function parseItems(json) {
    const o = []; const arr = (json && Array.isArray(json.result)) ? json.result : [];
    for (const rr of arr) {
      if (!rr || !rr.id) continue;
      const L = rr.listing || {}, it = rr.item || {}, pr = L.price || {}, st = L.stash || {}, ac = L.account || {};
      // PoE1 listings carry whisper_token; the field keeps its name —
      // it is "the token /whisper is POSTed with".
      // Token field: the unified backend uses the PoE2 name (hideout_token); legacy PoE1
      // responses carry whisper_token. Read both (mirrors the host TLS parser). lkeys =
      // raw listing keys, only for the no-token diagnostic (host ignores unknown fields).
      o.push({ itemId: rr.id, stashX: typeof st.x === 'number' ? st.x : -1, stashY: typeof st.y === 'number' ? st.y : -1, w: it.w || 1, h: it.h || 1, currency: pr.currency || '', amount: pr.amount || 0, seller: ac.name || '', stashName: st.name || '', name: it.name || '', typeLine: it.typeLine || '', baseType: it.baseType || '', rarity: it.rarity || '', iconUrl: it.icon || '', ilvl: it.ilvl || 0, corrupted: !!it.corrupted, identified: it.identified !== false, explicitMods: normMods(it.explicitMods), implicitMods: normMods(it.implicitMods), league: league, realm: realm, hideoutToken: L.hideout_token || L.whisper_token || '', indexedTime: L.indexed || '', lkeys: Object.keys(L).join(',') });
    }
    return o;
  }
  function groupBySeller(items) { const m = new Map(); for (const it of items) { const k = it.seller || '?'; if (!m.has(k)) m.set(k, []); m.get(k).push(it); } return [...m.entries()].map(([seller, items]) => ({ seller, items })); }
  // MIRROR of trade.js selectLargestSeller. `count` is the backend-declared maximum for this JWT,
  // not a request to buy across sellers.  Largest filtered seller wins; Map insertion order gives
  // the approved fetch-order tie break and item order is preserved verbatim.
  function selectLargestSeller(items, declaredCount) {
    const count = Number(declaredCount);
    if (!Number.isInteger(count) || count < 1 || count > 5 || !Array.isArray(items) || items.length > count) return null;
    const groups = new Map();
    for (let index = 0; index < items.length; ++index) {
      const item = items[index], seller = item && typeof item.seller === 'string' ? item.seller : '';
      if (!seller) continue;
      if (!groups.has(seller)) groups.set(seller, { seller, items: [], indexes: [] });
      const group = groups.get(seller); group.items.push(item); group.indexes.push(index);
    }
    let selected = null;
    for (const group of groups.values()) if (!selected || group.items.length > selected.items.length) selected = group;
    return selected;
  }
  // Currency profit filter (mirrors trade.js passesCurrencyFilter + host TLS path): no enabled filters
  // = buy any; else the item's currency must be enabled and amount within [min,max] (0 = unbounded).
  const passesFilter = (it) => { const f = S.filters; if (!f || !Object.keys(f).length) return true; const c = f[it.currency]; if (!c) return false; if (c.min > 0 && it.amount < c.min) return false; if (c.max > 0 && it.amount > c.max) return false; return true; };
  // Process one live message end-to-end. Latch is already held (claim granted).
  // PoE1 hands an id ARRAY from {"new":[ids]} — comma-joined, capped at the
  // fetch API's 10-id batch limit (mirrors trade.js fetchPathFor).
  async function processOne(ids, notificationAt, declaredCount) {
    const path = (Array.isArray(ids) ? ids : []).slice(0, 10).join(',');
    let json; try { json = await getJson(path); }
    catch (e) { out({ t: 'tradeevent', stage: 'fetch', outcome: 'fetch_error', detail: e.message }); release(); return; }
    const all = parseItems(json);
    const items = all.filter(passesFilter);   // currency profit filter BEFORE whisper
    const fetchReadyAt = performance.now();
    const timingDraft = { source: 'extension_live', partial: false, stages: [] };
    addRawStage(timingDraft, 'listing_fetch', notificationAt, fetchReadyAt);
    const sourceQueueAt = fetchReadyAt;
    out({ t: 'log', message: 'live: fetched ' + all.length + ' item(s), ' + items.length + ' passed filter in ' + new Set(items.map(i => i.seller)).size + ' seller(s)' });
    const selected = selectLargestSeller(items, declaredCount);
    if (!selected) {
      if (items.length) out({ t: 'log', message: 'live: fetched item count exceeded or did not match the declared maximum — dropped' });
      release(); return;
    }
    // Not-in-game gate (Task 11; mirrors trade.js ingameAllowed): the flag can flip between
    // claim-grant and whisper (live m.behavior update) — refuse the whisper and free the
    // latch exactly like the whisper-failed path below.
    if (S.behavior.ingame === false) { out({ t: 'log', message: 'whisper skipped (' + pauseText() + ')' }); release(); return; }
    // Host-not-ready re-check (2026-08-03; same shape as the ingame gate above): `ready`
    // folds the host's busy in, and busy now covers its auto-stash dump — the flag can flip
    // false between claim-grant and this line (the listing fetch sits in between). A whisper
    // is a teleport; refuse it and free the latch rather than yank the player out of their
    // own stash transfer. S.ready is refreshed by every ctl push (~400ms) and set true by
    // the claim grant itself, so a stale-init false can never eat the first listing.
    if (S.ready === false) { out({ t: 'log', message: 'whisper skipped (host busy — stash dump in progress?)' }); release(); return; }
    let candidates = selected.items.slice();
    let sourceStageAdded = false;
    while (candidates.length) {
      const first = candidates[0];
      const group = { searchId, groupId: searchId + '-' + first.itemId, isLastGroup: true, items: candidates };
      let prepareId = '';
      if (candidates.length >= 2 && S.behavior.packetBatch) {
        const ready = await prepare(group);
        if (!ready || !ready.ready || !ready.id) {
          out({ t: 'log', message: 'live: seller batch prepare failed (' + ((ready && ready.error) || 'not ready') + ') — whisper skipped' });
          release(); return;
        }
        prepareId = ready.id;
        S.activePrepareId = prepareId;
      }
      // Config/host readiness can change during the prepare round trip.  Cancel before any
      // teleport request if either gate closed.
      if (S.behavior.ingame === false || S.ready === false) {
        cancelPrepare(prepareId, S.behavior.ingame === false ? 'not_in_game' : 'host_not_ready');
        release(); return;
      }
      if (!first.hideoutToken) {
        const failedAt = performance.now();
        if (!sourceStageAdded) { addRawStage(timingDraft, 'source_queue', sourceQueueAt, failedAt, 'failed'); sourceStageAdded = true; }
        out({ t: 'log', message: 'live: listing has NO hideout/whisper token — trying the next item (listing keys: [' + (first.lkeys || '?') + '])' });
        out({ t: 'tradeevent', stage: 'whisper', outcome: 'whisper_failed', itemId: first.itemId, item: first, detail: 'no token in listing (keys: ' + (first.lkeys || '?') + ')', timingDraft });
        cancelPrepare(prepareId, 'missing_whisper_token');
        candidates = candidates.slice(1);
        continue;
      }
      const whisperAt = performance.now();
      if (!sourceStageAdded) { addRawStage(timingDraft, 'source_queue', sourceQueueAt, whisperAt); sourceStageAdded = true; }
      let retriedInDemand = false;
      S.whisperStarted = true;
      let w = await whisper(first.hideoutToken, S.behavior.forceTeleport);
      // "In demand" retry, BOTH games: ONE immediate re-send carrying continue:true.
      if (!w.ok && w.inDemand && S.behavior.inDemandRetry) {
        retriedInDemand = true;
        out({ t: 'tradeevent', stage: 'whisper', outcome: 'in_demand', itemId: first.itemId, item: first });
        w = await whisper(first.hideoutToken, true, true);
      }
      const whisperDoneAt = performance.now();
      S.whisperStarted = false;
      if (!w.ok) {
        out({ t: 'tradeevent', stage: 'whisper', outcome: (w.inDemand ? 'teleport_failed' : 'whisper_failed'), itemId: first.itemId, item: first, detail: String(w.status) + (w.msg ? (' ' + w.msg) : ''), timingDraft });
        cancelPrepare(prepareId, 'whisper_failed');
        candidates = candidates.slice(1);
        // Respect a stated site penalty; trying the next token inside it would refresh the ban.
        if (S.rateUntil > Date.now()) { release(); return; }
        continue;
      }
      addRawStage(timingDraft, 'whisper', whisperAt, whisperDoneAt,
                  retriedInDemand ? 'degraded' : 'ok');
      out({ t: 'log', message: (poe2 ? 'whisper ok -> teleport: ' : 'whisper sent -> seller: ') + (first.name || first.typeLine || first.baseType || first.itemId) + (candidates.length > 1 ? (' (+' + (candidates.length - 1) + ' more)') : '') + ' from ' + (first.seller || '?') });
      const bridgeDoneAt = performance.now();
      addRawStage(timingDraft, 'bridge_queue', whisperDoneAt, bridgeDoneAt);
      S.activePrepareId = '';
      out({ t: 'buy', prepareId, group: { ...group, timingDraft } });
      // BUY-PATH: do NOT release. The background keeps `busy` until buy_result.
      S.inFlight = false;
      return;
    }
    release();
  }
  // One live message arrives (PoE1 id array). Drop everything while in flight
  // or rate-limited; otherwise claim → process.
  async function onListing(ids, declaredCount) {
    const notificationAt = performance.now();
    const count = Number(declaredCount);
    if (!Number.isInteger(count) || count < 1 || count > 5) {
      out({ t: 'log', message: 'live: declared count ' + String(declaredCount) + ' is outside 1..5 — dropped' });
      return;
    }
    // Not-in-game drop (Task 11; mirrors trade.js ingameAllowed): BEFORE any fetch/claim.
    if (S.behavior.ingame === false) { out({ t: 'log', message: 'live: +' + ids.length + ' id(s) dropped (' + pauseText() + ')' }); return; }
    if (S.inFlight) { out({ t: 'log', message: 'live: +' + ids.length + ' id(s) dropped (previous fetch still in flight)' }); return; }
    if (S.behavior.rateLimit && S.rateUntil > Date.now()) { out({ t: 'log', message: 'live: +' + ids.length + ' id(s) dropped (rate-limited ' + Math.ceil((S.rateUntil - Date.now()) / 1000) + 's)' }); return; }
    S.inFlight = true;
    S.inFlightAt = Date.now();   // watchdog anchor — see beat()
    const granted = await claim();
    if (!granted) { S.inFlight = false; out({ t: 'log', message: 'live: +' + ids.length + ' id(s) dropped (buy latch denied: ' + (S.claimDenied || 'denied') + ')' }); return; }
    try { await processOne(ids, notificationAt, count); } catch (e) { try { out({ t: 'log', message: 'agent error: ' + e.message }); } catch (e2) {} release(); }
  }
  // --- liveness ---------------------------------------------------------------------------------
  // Heartbeat to the service worker, which re-arms this search if the beats stop (page discarded,
  // reloaded, crashed, frozen). It is also where a HALF-OPEN socket is caught. Every recycle costs
  // a WS upgrade and the upgrade count IS the rate-limit budget, so only evidence the socket is
  // BROKEN qualifies: a handshake wedged in CONNECTING, or this timer not running for far longer
  // than its own period — a machine waking from sleep, the one case where the socket is half-open
  // with no close event ever coming. Silence is NOT evidence (a narrow search receives nothing for
  // hours), and the `online` event is not either (it fires on any interface change, in every search
  // tab at once — N synchronized recycles was the 1.3.2 field regression).
  // MIRROR of trade.js shouldRecycleSocket (tests/trade.test.mjs is the tested reference).
  const recycle = (why) => {
    if (!mine()) return;
    out({ t: 'log', message: 'live: recycling the live socket (' + why + ')' });
    try { if (S.ws) S.ws.close(); } catch (e) {}   // → onclose → the background reconnects with backoff
  };
  const beat = () => {
    if (!mine()) { try { clearInterval(S.beatTimer); } catch (e) {} return; }
    const ws = S.ws, now = Date.now();
    const idleMs = now - S.lastMsgAt;
    const beatGapMs = now - S.lastBeatRunAt;
    S.lastBeatRunAt = now;
    const connectingMs = (ws && ws.readyState === 0) ? (now - S.openedAt) : 0;
    out({ t: 'beat', open: !!(ws && ws.readyState === 1), idleMs: idleMs });
    // In-flight watchdog (field bug 2026-08-05). S.inFlight spans ONE claim+fetch+whisper chain,
    // every leg of which is hard-bounded (claim failsafe 4 s, network calls 15 s each) — worst
    // legit case ~50 s. Anything older is a stuck flag (a lost claim reply, a fetch that ignored
    // its abort), and unrecovered it makes the search permanently deaf: every listing drops as
    // "previous fetch still in flight". 90 s keeps a wide margin over the legit worst case.
    // release() also frees the SW latch — safe when this agent doesn't hold it (the SW checks the
    // holder) — and the pre-whisper S.ready re-check keeps a later-resurrecting chain from
    // whispering into someone else's buy.
    if (S.inFlight && (now - (S.inFlightAt || 0)) >= 90000) {
      const heldSec = Math.round((now - (S.inFlightAt || 0)) / 1000);
      S.claimWaiter = null;
      release();
      out({ t: 'log', message: 'live: in-flight guard released after ' + heldSec + 's — a claim or fetch never completed' });
    }
    if (connectingMs > 30000) { recycle('handshake stuck'); return; }
    if (beatGapMs >= Math.max(BEAT_MS * 5, DEAD_MS)) recycle('this tab was asleep for ' + Math.round(beatGapMs / 60000) + ' min');
  };
  S.beatTimer = setInterval(beat, BEAT_MS);
  W.addEventListener('message', (e) => {
    const m = e.data && e.data[ch];
    if (e.source !== W || !m || m.ctl !== searchId || !mine()) return;
    if (m.probe) { beat(); return; }   // hidden-tab timers get throttled; the SW can ask directly
    if ('grant' in m && S.claimWaiter) {
      const r = S.claimWaiter; S.claimWaiter = null;
      // A grant is direct evidence the host was ready at that instant — seed S.ready from
      // it so the pre-whisper re-check can't trip on the initial `ready:false` before the
      // first ctl push lands (arming race; the check exists for LATER flips, not for init).
      if (m.grant) S.ready = true;
      S.claimDenied = m.grant ? '' : (typeof m.reason === 'string' && m.reason ? m.reason.replace(/_/g, ' ') : 'denied');
      r(!!m.grant);
    }
    if (m.prepareKey && S.prepareWaiter && m.prepareKey === S.prepareWaiter.key) {
      const waiter = S.prepareWaiter; S.prepareWaiter = null;
      waiter.resolve({ ready: !!m.ready, id: m.prepareId || '', error: m.error || '' });
    } else if ('ready' in m) S.ready = !!m.ready;
    if (m.behavior) S.behavior = m.behavior;
    if (m.filters) S.filters = m.filters;   // live currency-filter update
  }, { signal: listeners.signal });
  try {
    const ws = new WebSocket(liveUrl); S.ws = ws; S.openedAt = Date.now();
    ws.onopen = () => { S.lastMsgAt = Date.now(); out({ t: 'open' }); };
    ws.onmessage = (ev) => {
      if (!mine()) { try { ws.close(); } catch (e) {} return; }
      S.lastMsgAt = Date.now();
      let data = ''; try { data = typeof ev.data === 'string' ? ev.data : String(ev.data); } catch (e) {}
      let j; try { j = JSON.parse(data); } catch (e) { return; }
      if (j && ('auth' in j)) {                               // initial auth handshake
        if (j.auth === true) out({ t: 'log', message: 'live: WS authenticated' });
        else out({ t: 'log', message: 'live: WS AUTH FAILED — this browser profile is not logged into pathofexile.com; log in under the game account and restart the search' });
        return;
      }
      if (j && typeof j.result === 'string' && j.result) {    // current backend: one JWT may resolve to up to count listings
        const declaredCount = j.count === undefined ? 1 : j.count;
        out({ t: 'log', message: 'live: ' + String(declaredCount) + ' listing(s) declared (jwt)' });
        onListing([j.result], declaredCount);                 // fetch takes the JWT verbatim
        return;
      }
      if (j && Array.isArray(j.new)) {                        // legacy PoE1 live burst: {"new":["id",…]}
        const ids = j.new.filter(x => typeof x === 'string');
        if (ids.length) { out({ t: 'log', message: 'live: ' + ids.length + ' new id(s) received' }); onListing(ids, ids.length); }
        return;
      }
      // Anything else (server notices/errors) was invisible before — surface it bounded.
      out({ t: 'log', message: 'live: unhandled WS message: ' + data.slice(0, 160) });
    };
    // A superseded agent's close is swallowed by `out` (mine() is already false), so re-arming
    // never looks like a dropped search to the host.
    ws.onclose = (ev) => { try { clearInterval(S.beatTimer); } catch (e) {} out({ t: 'close', code: (ev && ev.code) || 0, reason: (ev && ev.reason) || '' }); };
    ws.onerror = () => {};
  } catch (e) { try { clearInterval(S.beatTimer); } catch (e2) {} out({ t: 'close', code: 0, reason: 'ws-init: ' + ((e && e.message) || 'error') }); }
}

// ===== MAIN-world one-shot helpers for the SW-owned manual buy (runManualBuy). =====
// Self-contained (executeScript serialises them by .toString()); they take primitives, do the
// credentialed trade-site network call in the page (real Origin/Referer/cookies → no 403), and
// RETURN data. No loop, no timers, no postMessage — the SW drives everything.

// Resolve the saved search, fetch the N cheapest matching listings, and return the picked items
// (whisper_token present + passes the currency filter). Returns { picked, budget } or { error }.
async function pfxMbFetchPick(host, realm, league, hash, itemCount, filters) {
  const F = filters || {};
  const modLine = (m) => (typeof m === 'string') ? m : ((m && typeof m.description === 'string') ? m.description : '');
  const normMods = (a) => Array.isArray(a) ? a.map(modLine).filter(s => s) : [];
  const passes = (it) => { if (!F || !Object.keys(F).length) return true; const c = F[it.currency]; if (!c) return false; if (c.min > 0 && it.amount < c.min) return false; if (c.max > 0 && it.amount > c.max) return false; return true; };
  let rateUntil = 0;
  const fetchT = async (url, opts) => { const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 15000); try { return await fetch(url, Object.assign({ signal: ctl.signal }, opts || {})); } finally { clearTimeout(t); } };
  async function getJson(url, opts) {
    const r = await fetchT(url, Object.assign({ credentials: 'include' }, opts || {}));
    let j = null; try { j = await r.json(); } catch (e) {}
    // MIRROR of trade.js rateLimitMsOf: HTTP 429 (Retry-After / "wait N seconds" body hint) OR the
    // in-band {"error":{"code":3,"message":"Rate limit exceeded; ..."}} the site sends on a 2xx.
    // Hint is regex-only by rule — a bare number in a message is never a wait.
    const err = j && j.error; const em = err ? String(err.message || '') : '';
    const inBand = !!(err && (err.code === 3 || /rate limit/i.test(em)));
    if (r.status === 429 || inBand) {
      const m = /wait\s+(\d+)\s+seconds/i.exec(em);
      const hint = m ? parseInt(m[1], 10) * 1000 : 0;
      const ra = r.status === 429 ? ((parseInt(r.headers.get('Retry-After'), 10) || 0) * 1000) : 0;
      rateUntil = Date.now() + (Math.max(ra, hint) || (r.status === 429 ? 10000 : 60000));
      throw new Error('rate limited');
    }
    if (!r.ok) throw new Error('http ' + r.status);
    if (j == null) throw new Error('bad json');
    return j;
  }
  function parseItems(json) {
    const out = []; const arr = (json && Array.isArray(json.result)) ? json.result : [];
    for (const rr of arr) {
      if (!rr || !rr.id) continue;
      const L = rr.listing || {}, it = rr.item || {}, pr = L.price || {}, st = L.stash || {}, ac = L.account || {};
      out.push({ itemId: rr.id, stashX: typeof st.x === 'number' ? st.x : -1, stashY: typeof st.y === 'number' ? st.y : -1, w: it.w || 1, h: it.h || 1, currency: pr.currency || '', amount: pr.amount || 0, seller: ac.name || '', stashName: st.name || '', name: it.name || '', typeLine: it.typeLine || '', baseType: it.baseType || '', rarity: it.rarity || '', iconUrl: it.icon || '', ilvl: it.ilvl || 0, corrupted: !!it.corrupted, identified: it.identified !== false, explicitMods: normMods(it.explicitMods), implicitMods: normMods(it.implicitMods), league, realm, hideoutToken: L.hideout_token || L.whisper_token || '', indexedTime: L.indexed || '' });
    }
    return out;
  }
  // MIRROR of trade.js looksCompressedSearchId/searchIdBytes/decodeSearchQuery (0.5.5 ids). This
  // function is serialised into the page's MAIN world and cannot import.
  const pfxDecodeQuery = async (id) => {
    try {
      if (typeof id !== 'string' || !id.startsWith('H4sI')) return null;
      if (id.length > 2048) return null;
      const s = id.replace(/=+$/, '').replace(/-/g, '+').replace(/_/g, '/');
      if (!s.length || s.length % 4 === 1 || /[^A-Za-z0-9+/]/.test(s)) return null;
      const bin = atob(s + '='.repeat((4 - (s.length % 4)) % 4));
      const bytes = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      const reader = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip')).getReader();
      const chunks = []; let total = 0;
      for (;;) {
        const { value, done } = await reader.read();
        if (done) break;
        total += value.byteLength;
        if (total > 64 * 1024) { await reader.cancel(); return null; }
        chunks.push(value);
      }
      const joined = new Uint8Array(total); let at = 0;
      for (const c of chunks) { joined.set(c, at); at += c.byteLength; }
      const obj = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(joined));
      if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return null;
      const q = obj.query;
      return (q && typeof q === 'object' && !Array.isArray(q)) ? q : obj;
    } catch (e) { return null; }
  };
  // Unified routing: non-empty realm ⇒ PoE2 (/api/trade2/…/<realm>/… + &realm=); empty ⇒ PoE1 (/api/trade).
  const poe2 = !!(realm && String(realm).length);
  try {
    // PoE2: /api/trade2/search/<realm>/<league>/<hash>, fetch with &realm=. PoE1: no realm segment.
    const resolveUrl = poe2
      ? ('https://' + host + '/api/trade2/search/' + encodeURIComponent(realm) + '/' + encodeURIComponent(league) + '/' + encodeURIComponent(hash))
      : ('https://' + host + '/api/trade/search/' + encodeURIComponent(league) + '/' + encodeURIComponent(hash));
    const postUrl = poe2
      ? ('https://' + host + '/api/trade2/search/' + encodeURIComponent(realm) + '/' + encodeURIComponent(league))
      : ('https://' + host + '/api/trade/search/' + encodeURIComponent(league));
    // MIRROR of trade.js JSON_GET_HEADERS (see there). The POST below keeps its own triad and
    // deliberately no Accept-Language — the browser's own chain rides that one.
    // 0.5.5: the id IS the query. Only a legacy id (or one that does not inflate) hits the resolve GET.
    let query = await pfxDecodeQuery(hash);
    if (!query) {
      const q = await getJson(resolveUrl, { headers: { 'Accept': 'application/json', 'Accept-Language': 'en-US', 'X-Requested-With': 'XMLHttpRequest' } });
      if (!q || !q.query) return { error: 'no query' };
      query = q.query;
    }
    const sj = await getJson(postUrl, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest', 'Accept': '*/*' }, body: JSON.stringify({ query, sort: { price: 'asc' } }) });
    const ids = (sj && Array.isArray(sj.result)) ? sj.result : [];
    const queryId = sj.id;   // fetch ?query= uses the POST response id (see WebSocketManager_ManualBuy.cpp)
    const budget = (itemCount | 0) > 0 ? (itemCount | 0) : ids.length;
    const picked = [];
    for (let i = 0; i < ids.length && picked.length < budget; i += 10) {
      // A stated penalty is an ABSOLUTE stop for the burst: return what is picked and let the SW
      // sit the FULL wait out. The old ≤2 s nibble marched every remaining batch through the
      // penalty, refreshing it each time.
      if (rateUntil > Date.now()) break;
      const batch = ids.slice(i, i + 10).join(',');
      const fetchUrl = poe2
        ? ('https://' + host + '/api/trade2/fetch/' + batch + '?query=' + encodeURIComponent(queryId) + '&realm=' + encodeURIComponent(realm))
        : ('https://' + host + '/api/trade/fetch/' + batch + '?query=' + encodeURIComponent(queryId));
      let fj; try { fj = await getJson(fetchUrl, { headers: { 'Accept': 'application/json', 'Accept-Language': 'en-US', 'X-Requested-With': 'XMLHttpRequest' } }); }   // MIRROR of trade.js JSON_GET_HEADERS
      catch (e) { continue; }
      for (const it of parseItems(fj)) { if (picked.length >= budget) break; if (it.hideoutToken && passes(it)) picked.push(it); }
    }
    return { picked, budget, rateMs: Math.max(0, rateUntil - Date.now()) };
  } catch (e) { return { error: (e && e.message) || 'fetch error', rateMs: Math.max(0, rateUntil - Date.now()) }; }
}

// POST one whisper. Force-teleport adds continue:'true' (STRING) for BOTH games (v1.3.0, MIRROR
// of trade.js whisperBody). The "in demand" retry runs on both games too (2026-07-31) and POSTs
// continue:true — a BOOLEAN, the site's own "whisper again" click; retry wins over force. Do not
// merge the two wire shapes.
// Returns { ok, inDemand, status, rateMs, msg } — SW decides.
async function pfxMbWhisper(host, token, poe2, force, retry) {
  const body = retry ? { token, continue: true }
                     : (force ? { token, continue: 'true' } : { token });
  const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 15000);
  let r;
  try {
    r = await fetch('https://' + host + '/api/' + (poe2 ? 'trade2' : 'trade') + '/whisper', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest', 'Accept': '*/*' }, body: JSON.stringify(body), signal: ctl.signal });
  } catch (e) {
    clearTimeout(t); return { ok: false, inDemand: false, status: 0, rateMs: 0 };   // timeout/network drop → skip group
  }
  clearTimeout(t);
  let b = {}; try { b = await r.json(); } catch (e) {}
  // MIRROR of trade.js rateLimitMsOf: HTTP 429 (Retry-After / "wait N seconds" body hint) OR the
  // in-band {"error":{"code":3,"message":"Rate limit exceeded; ..."}} on a 2xx — pre-1.3.5 the
  // in-band shape produced rateMs 0 and the SW whispered the next seller with NO delay at all.
  // Hint is regex-only by rule — a bare number in a message is never a wait.
  let rateMs = 0;
  const err = b && b.error; const em = err ? String(err.message || '') : '';
  const inBand = !!(err && (err.code === 3 || /rate limit/i.test(em)));
  if (r.status === 429 || inBand) {
    const m = /wait\s+(\d+)\s+seconds/i.exec(em);
    const hint = m ? parseInt(m[1], 10) * 1000 : 0;
    const ra = r.status === 429 ? ((parseInt(r.headers.get('Retry-After'), 10) || 0) * 1000) : 0;
    rateMs = Math.max(ra, hint) || (r.status === 429 ? 10000 : 60000);
  }
  // Surface the server's own explanation (mirrors the live agent's whisper) — a bare
  // "400" is undiagnosable; the host matches "must be in-game" for the account-mismatch stop.
  const msg = err ? String(err.message || err.code || '') : '';
  // BOTH games: success:false with NO error => "in demand" (the old PoE1 exclusion was an
  // assumption, disproven 2026-07-31).
  const inDemand = !!(b && b.success === false && !b.error);
  return { ok: r.ok && b && b.success === true, inDemand, status: r.status, rateMs, msg };
}

// Arm (or RE-arm) the page agent for a search. Every call mints a new generation token: the agent
// stamps it on the page, older agents see they were superseded, close their socket and stand down,
// and the background ignores anything they still say. That makes injection idempotent, which is
// what lets the supervisor below re-arm freely without ever risking two live sockets (= two
// whispers for one listing) in one document.
async function armAgent(sid, t, why) {
  if (!t || t.tabId == null || t.arming) return;
  // An owed reconnect backoff is an ABSOLUTE barrier, on every path that reaches an inject: the
  // sweep honors it in decideSearchRecovery, and this line covers the rest (a page load completing,
  // the scheduled-reconnect timer racing a re-schedule). An upgrade attempted inside a 1013 penalty
  // refreshes the penalty — before this check, a user F5 or a supervisor tab-repair during the
  // backoff reconnected immediately, and that is the 1.3.2 "rate limited for 30+ minutes" report.
  if (t.nextInjectAt && Date.now() < t.nextInjectAt) return;
  // NEVER re-arm the agent that is in the middle of a purchase for this search. Its whisper has
  // already teleported the player; superseding it now would drop the `buy` it is about to send.
  // (`out` delivers post-commit messages anyway — this is the belt to that braces, and it also
  // keeps the socket that the host's buy_result flow expects.)
  if (busy && busyHolder === sid) { t.nextInjectAt = Date.now() + 3000; return; }
  t.arming = true; t.armingAt = Date.now();
  const nonceAtStart = t.docNonce;
  try { await armAgentInner(sid, t, why); }
  finally {
    t.arming = false;
    // A new document announced itself while this arm was in flight and un-marked the search
    // (noteDocument): whatever landed, if anything, is in the previous document. Arm the new one.
    if (searchTabs.get(sid) === t && t.docNonce !== nonceAtStart && !t.injected) armIfComplete(sid, t);
  }
}
async function armAgentInner(sid, t, why) {
  // The agent only works on the search's own page: it fetches and whispers with the site's own
  // origin and cookies. A tab that wandered off is NOT handled here — the sweep owns the steering
  // (one code path, one navStreak backoff; a second, flat-gap path here is how a logged-out profile
  // ended up navigating + attempting an upgrade once a minute forever).
  let tab = null;
  try { tab = await chrome.tabs.get(t.tabId); } catch (e) { tab = null; }
  if (searchTabs.get(sid) !== t) return;      // the search was removed while we awaited
  if (!tab) { t.tabId = null; saveTabRegistry(); return; }
  if (!isSearchTabUrl(tab.url, t.search)) {          // the sweep steers it back on its own schedule
    logRefusal(sid, `not arming — the tab is on ${String(tab.url).split('?')[0].slice(0, 200)}, not this search's page`);
    return;
  }
  t.navStreak = 0;              // it is on the right page again: forget the steering backoff
  // Hoisted ABOVE the barrier re-check: from that check to executeScript there must be no await, or
  // a searchClose can interleave and set a fresh penalty that the publication below then wipes.
  const ch = await ensureCh();
  if (searchTabs.get(sid) !== t) return;      // the search was removed while we awaited
  // Re-check the backoff barrier. armAgent checked it before the awaits above — but a searchClose
  // landing DURING them (the socket we are superseding dying with a 1013) books a penalty that
  // `t.nextInjectAt = 0` at publication would silently erase (review 2026-07-30).
  if (t.nextInjectAt && Date.now() < t.nextInjectAt) return;
  // SINGLE-FLIGHT. A queued executeScript (frozen tab) is still owed to the browser: issuing more
  // piles more queued agents that all land at thaw, each opening a socket. While one is unsettled,
  // only the sweep may act — and its move is replacing the document (injectStuck → reload), never
  // another inject.
  if (t.injectPending) { t.nextInjectAt = Date.now() + 15000; return; }
  // GLOBAL upgrade gate: this is the one place a live agent (and so a live WS upgrade) is created.
  // Not granted ⇒ book the retry through the same nextInjectAt machinery every other deferral uses.
  // The timer is the fast path (a fleet bring-up serializes at the gate gap, not at one search per
  // 24 s sweep tick); the sweep's scheduled-reconnect rule is the durable one that still fires if
  // the worker (and this timer with it) is torn down.
  const gateWait = gateReserve(wsGate, Date.now(), Math.random(), searchTabs.size);
  if (gateWait > 0) {
    // Sub-minute deferrals are routine pacing; an HOUR-scale one (account hold / spent budget) is
    // invisible without a line, and the field report for invisible is "the extension stopped
    // searching". Say which it is and for how long, at most once per 10 min per search.
    if (gateWait > 60000 && Date.now() - (t.lastGateLogAt || 0) > 600000) {
      t.lastGateLogAt = Date.now();
      const mins = Math.ceil(gateWait / 60000);
      log(wsGate.holdUntil > Date.now()
        ? `Live search ${String(sid).slice(0, 8)}…: the account is rate-limit held — next connection attempt in ${mins} min`
        : `Live search ${String(sid).slice(0, 8)}…: the hourly connection budget is spent (${(wsGate.opens || []).length} upgrades this hour) — next attempt in ${mins} min`);
    }
    t.nextInjectAt = Date.now() + gateWait;
    setTimeout(() => { const tt = searchTabs.get(sid); if (tt && tt.nextInjectAt && Date.now() >= tt.nextInjectAt) armAgent(sid, tt, why); }, gateWait + 50);
    return;
  }
  saveGate();
  const gen = newGen(t);
  // Published BEFORE the inject: the agent starts running inside executeScript and its first
  // message (`open`) can arrive before the promise resolves — with the generation still unset it
  // would be rejected as stale.
  t.gen = gen; t.injected = true; t.nextInjectAt = 0;
  // The PREVIOUS agent's socket-open time must not classify THIS agent's close: without this, a
  // new socket 1013'd before its own searchOpen inherited a stale lastOpenAt and read as healthy —
  // resetting the per-search backoff and starving the fleet gate of the failure (review 2026-07-30).
  t.lastOpenAt = 0;
  t.lastBeatAt = Date.now();        // grace: the first real beat is one interval away
  try {
    // BOUNDED. `executeScript` against a FROZEN tab neither resolves nor rejects — the injection is
    // queued until the tab thaws (w3c/webextensions#527). An unbounded await there would leave
    // `arming` set forever and the sweep would skip this search for good: the exact
    // silently-dead-search bug this supervisor exists to prevent. A late injection is safe twice
    // over: generations are monotonic (a stale agent yields to a newer one on the page), and the
    // agent self-cancels by AGE when it lands ≥ injectStuckMs after issue — which is exactly when
    // it can land in a REPLACED, generation-less document where the yield check has nothing to
    // compare against (the injectStuck reload only ever happens ≥ injectStuckMs after issue).
    const issuedAt = Date.now();
    const exec = chrome.scripting.executeScript({
      target: { tabId: t.tabId }, world: 'MAIN', func: pfxLiveAgent,
      args: [liveWsUrl(t.search), t.search.searchId, t.search.realm, t.search.league, hostBehavior,
             t.search.filters || {}, ch, gen,
             { beatMs: LIVENESS.beatMs, deadMs: LIVENESS.deadMs, stuckMs: LIVENESS.injectStuckMs, issuedAt }]
    });
    t.injectPending = true; t.injectIssuedAt = issuedAt;
    // Only THIS inject's settling clears the flag: a stale queued inject settling late (it lands,
    // sees a newer generation, stands down, resolves) must not un-mark a newer one still owed.
    Promise.resolve(exec).then(() => {}, () => {}).finally(() => { if (t.injectIssuedAt === issuedAt) t.injectPending = false; });
    const timeoutErr = new Error('inject timed out (tab frozen?)'); timeoutErr.pfxTimeout = true;
    await Promise.race([
      exec,
      new Promise((_, reject) => setTimeout(() => reject(timeoutErr), LIVENESS.injectTimeoutMs))
    ]);
    t.injectFailStreak = 0;
    if (why) log(`Live agent armed for ${String(sid).slice(0, 8)}… (${why})`);
    setTimeout(pushCtl, 500);
  } catch (e) {
    if (e && e.pfxTimeout) {
      // TIMED OUT ≠ failed: the injection is queued and may still land. Keep the generation
      // published so a late-but-legit landing (< injectStuckMs) is accepted with its beats; if it
      // lands later it stands down by age, and if it never lands the dead window / injectStuck
      // ladder replaces the document. Nulling the gen here (pre-review behavior) made every
      // sub-30s thaw cost one wasted upgrade: the landed agent's beats were refused as stale.
      log(`Inject queued (${t.search.note}): the tab is not responding — waiting for it to land or be replaced`);
    } else if (t.gen === gen) {
      // A REJECTED inject used to be terminal (the old one-way `injected` latch never retried).
      // Retry in seconds — and count it: two consecutive rejections escalate to a reload in the
      // sweep (decideSearchRecovery), which revives a crashed document and, failing that, parks.
      t.injected = false; t.gen = null; t.nextInjectAt = Date.now() + 5000;
      t.injectFailStreak = (t.injectFailStreak | 0) + 1;
      log(`Inject failed (${t.search.note}): ${e.message}`);
    }
  }
}
// Monotonic per search, and monotonic ACROSS service-worker restarts (clock-based): a queued
// injection landing late must always find an equal-or-newer number on the page and stand down.
function newGen(t) {
  t.genLast = Math.max(Date.now(), (t.genLast || 0) + 1);
  return t.genLast;
}

function pushCtl() {
  for (const t of searchTabs.values()) {
    if (t.tabId == null) continue;
    chrome.tabs.sendMessage(t.tabId, { cmd: 'ctl', searchId: t.search.searchId, ready: hostReady, behavior: hostBehavior, filters: t.search.filters || {} }).catch(() => {});
  }
}

// Find the tab that is already THIS search's. The service worker's map dies with the worker, so
// without this a worker restart opened a SECOND tab per search (two live sockets, two whispers per
// listing) while the first kept running untracked. Three tiers, most certain first:
//   1. the registry — the tab we assigned to this search, still a pinned tab on its page;
//   2. a pinned tab carrying this search's OWN id (a legacy id, or a 0.5.5 tab caught before the
//      site re-spelled it);
//   3. a DISCARDED pinned tab on this search's page — a browser-restored session comes back under
//      new tab ids and unloaded, so nothing can be running there and the registry cannot name it;
//   4. a LOADED pinned tab on this search's page that opted out of discarding — only this extension
//      sets `autoDiscardable: false` (ensureSearchTab, startManualBuy), so such a tab is ours, just
//      not nameable: the registry was lost (an extension update wipes nothing here, but a failed
//      write or a version that had no registry — 1.4.2 — leaves loaded tabs behind with agents
//      whose content scripts an update has orphaned). It is navigated to this search's URL, which
//      replaces whatever runs in it. Chrome does not restore the opt-out across sessions.
// A LOADED tab none of these name is left alone: with 0.5.5 ids it may be the user's own tab in
// the same league (all of them re-spelled, so all alike by URL). The chosen tab is reserved on the
// spot, before any await: applyConfig opens every search concurrently and two entries must never
// adopt one tab (their page agents would tear each other down on every re-arm).
// Returns { tabId, how, exact } or null.
async function findExistingTab(t) {
  const search = t.search;
  try {
    // The manual-buy tab sits on the same URL and is pinned too — adopting it would put a live
    // agent inside a tab that gets closed the moment the bulk buy ends, and (because the search
    // branch of onUpdated returns first) the bulk-buy loop would never start. While it is being
    // created its id is still null, so adopt nothing at all in that window.
    if (manualBuy && manualBuy.tabId == null) return null;
    const mbTab = manualBuy ? manualBuy.tabId : null;
    const registry = await loadTabRegistry();
    const tabs = await chrome.tabs.query({});
    const owned = new Set(reservedTabIds);
    for (const e of searchTabs.values()) if (e !== t && e.tabId != null) owned.add(e.tabId);
    const usable = (tb) => !!tb && tb.pinned && tb.id !== mbTab && !owned.has(tb.id) && !closingTabIds.has(tb.id);
    // `pendingUrl` carries the target of a navigation in flight (`url` is the committed page, empty
    // for a brand-new tab); a tab on its way back to the search page is judged by where it is going.
    const kindOf = (tb) => {
      const a = tb.pendingUrl ? searchTabUrlMatch(tb.pendingUrl, search) : null;
      const b = tb.url ? searchTabUrlMatch(tb.url, search) : null;
      return (a === 'exact' || b === 'exact') ? 'exact' : (a || b);
    };
    let hit = null, how = '';
    const remembered = registry[search.searchId];
    const rt = (remembered != null) ? tabs.find(tb => tb && tb.id === remembered) : null;
    if (rt && usable(rt) && kindOf(rt)) { hit = rt; how = 'remembered'; }
    if (!hit) { const ex = tabs.find(tb => usable(tb) && kindOf(tb) === 'exact'); if (ex) { hit = ex; how = 'by id'; } }
    if (!hit) { const d = tabs.find(tb => usable(tb) && tb.discarded === true && kindOf(tb) === 'page'); if (d) { hit = d; how = 'restored by the browser'; } }
    if (!hit) { const o = tabs.find(tb => usable(tb) && tb.discarded !== true && tb.autoDiscardable === false && kindOf(tb) === 'page'); if (o) { hit = o; how = 'ours, unassigned'; } }
    if (!hit) return null;
    reservedTabIds.add(hit.id);
    return { tabId: hit.id, how, exact: kindOf(hit) === 'exact' };
  } catch (e) { return null; }
}

// Give an armed search a tab: adopt the one that is already there, else open one. Opted out of
// automatic discarding for the same reason the manual-buy tab is — a discarded background tab loses
// its live socket with no close event and no way back (this is the "extension misses incoming
// items" field bug).
async function ensureSearchTab(sid, t, why) {
  if (t.opening) return;
  t.opening = true; t.openingAt = Date.now();
  let reload = null, navigateTo = null;
  try {
    const found = await findExistingTab(t);
    if (searchTabs.get(sid) !== t) { if (found) reservedTabIds.delete(found.tabId); return; }   // removed while we awaited
    const fresh = !found;
    let tabId;
    if (fresh) {
      const tab = await chrome.tabs.create({ url: searchPageUrl(t.search), active: false, pinned: true });
      tabId = tab.id;
      log(`Opened tab for ${t.search.note}${why ? ' (' + why + ')' : ''}`);
    } else {
      tabId = found.tabId;
      if (t.tabId !== tabId) log(`Adopted existing tab for ${t.search.note} (${found.how}${why ? '; ' + why : ''})`);
    }
    // Claim the id BEFORE any further await: the tab's own loading/complete events are what arm the
    // agent, and they are ignored while no entry owns that id.
    t.tabId = tabId; t.injected = false; t.gen = null; t.injectPending = false; t.lastBeatAt = Date.now();
    t.loadStartedAt = Date.now(); t.reopenAt = 0;
    reservedTabIds.delete(tabId);
    saveTabRegistry();
    // A fresh tab's load is OURS (marked here, in the same turn the id was claimed, so the new
    // document's own announcement cannot precede the mark). An adopted tab is marked right before
    // the reload below — the tab may still be loading its current document, whose announcement
    // must not consume the mark meant for the load we are about to order.
    if (fresh) t.expectNav = true;
    // An adopted tab is RELOADED, not injected into. Adoption happens after a worker restart, and
    // an extension update rotates the in-page channel token AND orphans the old content script — so
    // the agent already running in that document could neither be torn down (its teardown thunk
    // lives under the old token) nor talk to us. Two live sockets in one document, permanently.
    // A fresh document costs one page load and guarantees exactly one agent.
    // A tab adopted by page rather than by id (a restored, discarded tab on this league's search
    // page) is NAVIGATED to this search's own URL: the page it shows may be another query's.
    if (!fresh) { reload = tabId; if (!found.exact && found.how !== 'remembered') navigateTo = searchPageUrl(t.search); }
    try { await chrome.tabs.update(tabId, { autoDiscardable: false }); } catch (e) {}
  } catch (e) {
    log(`Open tab failed (${t.search.note}): ${e.message}`);
    t.reopenAt = Date.now() + 15000;   // don't spin on a browser that refuses to open tabs
  } finally { t.opening = false; }
  if (reload != null && searchTabs.get(sid) === t) {
    t.expectNav = true;
    try { if (navigateTo) await chrome.tabs.update(reload, { url: navigateTo }); else await chrome.tabs.reload(reload); } catch (e) {}
  }
}

async function openSearchTab(search) {
  if (searchTabs.has(search.searchId)) return;
  const t = { tabId: null, search, injected: false, lastOpenAt: 0, failStreak: 0, gen: null,
              lastBeatAt: Date.now(), nextInjectAt: 0, lastRecoverAt: 0, recoverStreak: 0 };
  searchTabs.set(search.searchId, t);
  await ensureSearchTab(search.searchId, t, '');
}
async function closeSearchTab(searchId) {
  const t = searchTabs.get(searchId); searchTabs.delete(searchId); saveTabRegistry();
  if (t && t.tabId != null) { const id = t.tabId; closingTabIds.add(id); try { await chrome.tabs.remove(id); } catch (e) {} closingTabIds.delete(id); }
}

function entryForTab(tabId) { for (const [sid, t] of searchTabs.entries()) if (t.tabId === tabId) return [sid, t]; return [null, null]; }
// Is this message from the agent that currently owns the search? Only a positively confirmed match
// counts: an unknown search, or a generation we cannot vouch for, is refused.
function genOk(sid, g) { const t = searchTabs.get(sid); return !!(t && t.gen && g && t.gen === g); }
function staleText(req) {
  const t = searchTabs.get(req.sid);
  return `${req.cmd} from a stale agent refused (its generation ${req.g}, current ${t ? (t.gen || 'none') : 'no such search'})`;
}

// The liveness sweep: the ONE place that decides whether an armed search is actually alive. Driven
// by the keepalive alarm because a service worker can be torn down at any moment and alarms are the
// only timer that survives it (a pending setTimeout does not).
let sweeping = false;
async function sweepSearches() {
  if (sweeping) return;      // a sweep that opens tabs can outlast the alarm period
  sweeping = true;
  try { await sweepSearchesInner(); } finally { sweeping = false; }
}
async function sweepSearchesInner() {
  for (const [sid, t] of [...searchTabs.entries()]) {
    const now = Date.now();
    if (searchTabs.get(sid) !== t) continue;                   // removed while we awaited
    // In-flight guards, with an escape hatch: a wedged await must not park a search forever — that
    // is the failure mode this whole file exists to remove.
    if (t.opening && now - (t.openingAt || 0) < 90000) continue;
    if (t.arming && now - (t.armingAt || 0) < 90000) continue;
    if (t.opening || t.arming) { t.opening = false; t.arming = false; log(`Live search ${String(sid).slice(0, 8)}…: a stuck recovery step was released`); }
    if (t.tabId == null && t.reopenAt && now < t.reopenAt) continue;
    let tab = null;
    if (t.tabId != null) { try { tab = await chrome.tabs.get(t.tabId); } catch (e) { tab = null; } }
    if (searchTabs.get(sid) !== t) continue;                   // removed while we awaited
    const d = decideSearchRecovery({
      now,
      tabMissing: !tab,
      discarded: !!(tab && tab.discarded),
      frozen: !!(tab && tab.frozen === true),                  // Chrome 132+; undefined elsewhere
      navStreak: t.navStreak,
      // Only a FRESH load is a reason to wait. A tab wedged in `loading` (dead network, hung
      // renderer) would otherwise be exempt from every liveness rule forever.
      loading: !!(tab && tab.status && tab.status !== 'complete') &&
               (now - (t.loadStartedAt || 0)) < LIVENESS.deadMs,
      offPage: !!(tab && !isSearchTabUrl(tab.url, t.search)),
      lastNavAt: t.lastNavAt,
      lastBeatAt: t.lastBeatAt, nextInjectAt: t.nextInjectAt,
      lastRecoverAt: t.lastRecoverAt, recoverStreak: t.recoverStreak,
      injectStuck: !!t.injectPending && (now - (t.injectIssuedAt || 0)) >= LIVENESS.injectStuckMs,
      injectFailStreak: t.injectFailStreak,
      busyHere: busy && busyHolder === sid
    });
    if (d.action === 'none') {
      // A search crossing into parked is reported ONCE — to the log and to the host UI — instead of
      // silently going dark (the silent version of this is the exact bug the supervisor exists for).
      if (d.reason === 'parked after repeated failed recoveries' && !t.parkedLogged) {
        t.parkedLogged = true;
        t.hostState = 'closed';
        if (ptbp) ptbp.sendSearchStatus(sid, 'closed');
        log(`Live search ${String(sid).slice(0, 8)}…: ${t.recoverStreak} recoveries brought no heartbeat — parked, retrying every ${Math.round(LIVENESS.parkRetryMs / 60000)} min`);
      }
      continue;
    }
    if (d.action === 'probe') { probeAgent(t); continue; }
    if (d.action === 'navigate') {
      t.lastNavAt = now; t.navStreak = (t.navStreak | 0) + 1;
      t.injected = false; t.gen = null; t.loadStartedAt = now; t.lastBeatAt = now; t.expectNav = true;
      const at = String(tab.url).split('?')[0].slice(0, 200);
      log(t.navStreak >= 3
        ? `Search tab for ${t.search.note} keeps landing on ${at} — is this browser profile logged in to the trade site?`
        : `Search tab for ${t.search.note} is on ${at} — steering it back to the search page`);
      try { await chrome.tabs.update(t.tabId, { url: searchPageUrl(t.search) }); } catch (e) {}
      continue;
    }
    // A tab that has not finished loading cannot be injected into usefully: the agent would land in
    // the pre-commit document and be thrown away by the navigation, with `injected` left true.
    const action = (d.action === 'inject' && tab && tab.status && tab.status !== 'complete') ? 'reload' : d.action;
    if (action !== 'inject') {   // reopen / reload: the document itself has to be replaced
      t.lastRecoverAt = now; t.recoverStreak = (t.recoverStreak | 0) + 1;
      log(`Live search ${String(sid).slice(0, 8)}…: ${d.reason} — recovering (${action})`);
      if (action === 'reopen') {
        // Close it first: reloading is not a documented way out of a frozen document, and
        // ensureSearchTab would otherwise adopt the very tab we are trying to replace.
        const dead = t.tabId; t.tabId = null; t.injected = false; t.gen = null; t.injectPending = false;
        saveTabRegistry();
        if (dead != null) { closingTabIds.add(dead); try { await chrome.tabs.remove(dead); } catch (e) {} closingTabIds.delete(dead); }
        if (searchTabs.get(sid) === t) await ensureSearchTab(sid, t, d.reason);
      } else {
        // Replacing the document also releases the single-flight latch: an inject queued against
        // the old document either dies with it or lands late and stands down (monotonic gen).
        t.injected = false; t.gen = null; t.injectPending = false; t.lastBeatAt = now; t.loadStartedAt = now;
        t.expectNav = true;
        try { await chrome.tabs.reload(t.tabId); }
        catch (e) { t.tabId = null; saveTabRegistry(); if (searchTabs.get(sid) === t) await ensureSearchTab(sid, t, 'reload failed'); }
      }
      continue;
    }
    if (d.reason !== 'scheduled reconnect') { t.lastRecoverAt = now; t.recoverStreak = (t.recoverStreak | 0) + 1; log(`Live search ${String(sid).slice(0, 8)}…: ${d.reason} — re-arming the agent`); }
    await armAgent(sid, t, d.reason);
  }
}
// Ask the tab directly whether its agent is alive. A runtime message is not subject to the timer
// throttling that slows a hidden tab's heartbeat, so an answer proves liveness; silence does not
// prove death on its own (a frozen tab queues the message) — that is what the dead window is for.
function probeAgent(t) {
  if (t.tabId == null) return;
  chrome.tabs.sendMessage(t.tabId, { cmd: 'probe', searchId: t.search.searchId }).catch(() => {});
}

chrome.tabs.onUpdated.addListener((tabId, info) => {
  const [sid, t] = entryForTab(tabId);
  if (t) {
    // A load began — a real navigation OR the site's own same-document URL rewrite (0.5.5 re-spells
    // the search id right after every load, and Chrome reports that as loading→complete as well).
    // Nothing is reset here: the two are told apart by the content script, which runs once per NEW
    // document and announces it (noteDocument) — the pre-1.4.3 reset on every 'loading' is what
    // orphaned a healthy agent on every rewrite. Only the liveness clock notes the load.
    if (info.status === 'loading') t.loadStartedAt = Date.now();
    if (info.status === 'complete') reconcileDocument(sid, t, tabId);
    return;
  }
  if (info.status !== 'complete') return;
  if (manualBuy && manualBuy.tabId === tabId && !manualBuy.started) {
    manualBuy.started = true;
    runManualBuy(tabId).catch(e => { if (manualBuy) finishManualBuy('error', { detail: 'loop error: ' + (e && e.message) }); });
  }
});
// A discard can change a tab's id (the page is replaced rather than removed). Follow it, or the
// entry points at an id that no longer exists and the search takes an extra recovery round-trip.
// Chrome-only — Firefox has no `tabs.onReplaced`, and an unguarded reference here would throw at
// load time and take the whole background script down with it.
try {
  if (chrome.tabs.onReplaced) chrome.tabs.onReplaced.addListener((addedTabId, removedTabId) => {
    const [, t] = entryForTab(removedTabId);
    if (!t) return;
    t.tabId = addedTabId; t.injected = false; t.gen = null; t.injectPending = false; t.docNonce = undefined;
    t.lastBeatAt = Date.now(); t.loadStartedAt = Date.now();
    t.expectNav = true;   // a browser-internal swap, not an external reloader
    saveTabRegistry();
  });
} catch (e) {}
chrome.tabs.onRemoved.addListener((tabId, info) => {
  if (manualBuy && manualBuy.tabId === tabId) { finishManualBuy('cancelled', { detail: 'tab closed' }); return; }
  const [sid, t] = entryForTab(tabId);
  if (!sid) return;
  // The search stays ARMED (the program owns the search list, not the browser): closing the tab —
  // or closing the window it lived in — used to kill that search until the user toggled it in
  // POEFixer. The sweep reopens it. When the whole WINDOW is going away, wait a minute first: on a
  // browser shutdown the reopen would race the exit and could pop a window back up.
  t.tabId = null; t.injected = false; t.gen = null; t.injectPending = false; t.docNonce = undefined;
  t.reopenAt = Date.now() + ((info && info.isWindowClosing) ? 60000 : 5000);
  saveTabRegistry();
  t.hostState = 'closed';
  if (ptbp) ptbp.sendSearchStatus(sid, 'closed');
  log(`Tab closed for ${sid.slice(0, 8)}… — reopening shortly`);
});

async function start() {
  const s = await store.getSettings();
  if (ptbp) ptbp.close();
  ptbp = new PtbpClient({
    // Loopback only: the remote-extension mode (host/key pairing to another machine) was removed
    // in S43 — the host bridge listens plaintext on 127.0.0.1 and nowhere else.
    url: `ws://127.0.0.1:${s.port || 47362}`, client: 'PoeFixerExt/1.0', token: s.tokenOn ? s.token : '', version: (chrome.runtime.getManifest && chrome.runtime.getManifest().version) || '',
    onOpen: () => log('Host connected'),
    onClose: () => { hostReady = false; clearBusy('host-disconnect'); pushCtl(); },
    onWelcome: (w) => {
      // A host that (re)connected knows nothing about the sockets already open: the next heartbeat
      // of each armed search re-announces 'connected' (see case 'beat').
      for (const t of searchTabs.values()) t.hostState = '';
      log(`Welcome: allowed=${w.allowed} paid=${w.paid}`);
    },
    onStatus: (st) => { hostReady = !!st.ready; pushCtl(); },
    onConfig: (c) => applyConfig(c),
    onBuyProgress: (p) => log(`Buy ${p.id}: ${p.phase}`),
    onManualBuy: (m) => startManualBuy(m),
    onManualBuyCancel: (m) => cancelManualBuy(m && m.id),
    onBuyResult: (r) => {
      clearBusy('buy_result');
      // SW-owned manual buy waits for the result HERE (no relay into the throttle-prone tab).
      if (manualBuy && manualBuy.buyResolve) { const f = manualBuy.buyResolve; manualBuy.buyResolve = null; if (manualBuy.buyTimer) { clearTimeout(manualBuy.buyTimer); manualBuy.buyTimer = null; } f(r); }
      log(`Buy ${r.id}: ${r.summary ? r.summary.bought + ' bought / ' + r.summary.failed + ' failed / ' +
        (r.summary.unknown || 0) + ' unknown / ' + (r.summary.skipped || 0) + ' skipped' : 'done'}`);
    },
    onError: (e) => { clearBusy('host-error'); log(`Host error: ${e.code}${e.detail ? ' ' + e.detail : ''}`); }
  });
  ptbp.connect();
}

function applyConfig(c) {
  // normalizeBehavior (trade.js, tested) adds ingame — missing in the JSON ⇒ true (old host).
  if (c.behavior) hostBehavior = normalizeBehavior(c.behavior);
  const list = Array.isArray(c.searches) ? c.searches : [];
  const wanted = new Set(list.map(s => s.searchId));
  for (const sid of [...searchTabs.keys()]) if (!wanted.has(sid)) closeSearchTab(sid);
  for (const s of list) {
    const ex = searchTabs.get(s.searchId);
    if (ex) ex.search.filters = s.filters || {};   // live currency-filter update for an already-open search
    else openSearchTab({ realm: s.realm, domain: s.domain, league: s.league, searchId: s.searchId, note: s.note || s.searchId, filters: s.filters || {} });
  }
  pushCtl();
  log(`Config: ${list.length} search(es), force=${hostBehavior.forceTeleport} demand=${hostBehavior.inDemandRetry} rate=${hostBehavior.rateLimit} ingame=${hostBehavior.ingame}` +
      (hostBehavior.ingame ? '' : ` (${pauseReasonText(hostBehavior)})`));
}

chrome.runtime.onMessage.addListener((req, _s, sendResponse) => {
  (async () => {
    switch (req && req.cmd) {
      case 'getState': { const s = await store.getSettings(); sendResponse({ hostConnected: !!(ptbp && ptbp.connected), ready: !!(ptbp && ptbp.ready), port: s.port }); break; }
      case 'setPort': await store.setSettings({ port: req.port }); await start(); sendResponse({ ok: true }); break;
      case 'searchOpen': {
        if (!genOk(req.sid, req.g)) { logRefusal(req.sid, staleText(req)); sendResponse({ ok: false }); break; }
        const t = searchTabs.get(req.sid);
        if (t) { t.lastOpenAt = Date.now(); t.lastBeatAt = Date.now(); t.recoverStreak = 0; t.injectFailStreak = 0; t.parkedLogged = false; t.hostState = 'connected'; }
        gateRecordOpen(wsGate, Date.now()); saveGate();
        if (ptbp) ptbp.sendSearchStatus(req.sid, 'connected');
        log(`Live search connected: ${String(req.sid).slice(0, 8)}…`); sendResponse({ ok: true }); break;
      }
      case 'searchClose': {
        // Only the CURRENT agent may report a drop: a superseded one closes its socket on the way
        // out, and letting that count would schedule a redundant re-inject and flap the host UI.
        if (!genOk(req.sid, req.g)) { logRefusal(req.sid, staleText(req)); sendResponse({ ok: false }); break; }
        if (ptbp) ptbp.sendSearchStatus(req.sid, 'closed');
        const t = searchTabs.get(req.sid);
        if (t) t.hostState = 'closed';
        const openMs = (t && t.lastOpenAt) ? (Date.now() - t.lastOpenAt) : 0;
        const healthy = openMs >= HEALTHY_OPEN_MS;
        // The fleet gate learns about every sub-healthy close. An explicit 1013 holds the WHOLE
        // fleet at once (the penalty is per-account; the 3-strike cluster stays for other codes) —
        // the per-search backoff below cannot see that the budget being burned is shared.
        gateRecordClose(wsGate, Date.now(), healthy, req.code | 0); saveGate();
        if ((req.code | 0) === 1013 && wsGate.holdUntil > Date.now() && Date.now() - last1013LogAt > 30000) {
          last1013LogAt = Date.now();
          log(`Rate-limiting is active for this account (live WS closed 1013) — pausing ALL live searches for ${Math.ceil((wsGate.holdUntil - Date.now()) / 60000)} min (episode ${wsGate.streak1013 | 0})`);
        }
        let streak = 1;
        if (t) { t.lastOpenAt = 0; t.failStreak = healthy ? 0 : (t.failStreak || 0) + 1; streak = t.failStreak; }
        // Jittered on BOTH branches. `online` (and any shared network blip) closes every search's
        // socket in the same tick; N healthy reconnects landing at exactly +5000 ms is the shape
        // GGG answers with a 1013, which then pushes searches that were fine into a real backoff.
        const delay = Math.round((healthy ? RECONNECT_BASE_MS
                                          : Math.min(RECONNECT_BASE_MS * Math.pow(2, streak - 1), RECONNECT_MAX_MS))
                                 * (0.8 + Math.random() * 0.4));
        const codeStr = (req.code || req.reason) ? ` (code ${req.code || 0}${req.reason ? ' ' + String(req.reason) : ''})` : '';
        log(`Live search dropped: ${String(req.sid).slice(0, 8)}…${codeStr}${(!healthy && streak > 1) ? ` — backing off ${Math.round(delay / 1000)}s (attempt ${streak})` : ''}`);
        // Recorded as a DEADLINE as well as a timer, so the reconnect has two independent paths to
        // it: the timer is the fast one, the alarm-driven sweep is the one that still fires if the
        // callback is lost or skipped. (A worker teardown drops the whole map, not just the timer —
        // the searches are then rebuilt from the host's config push, which re-arms them itself.)
        if (t) t.nextInjectAt = Date.now() + delay;
        setTimeout(() => { const tt = searchTabs.get(req.sid); if (tt && tt.nextInjectAt && Date.now() >= tt.nextInjectAt) armAgent(req.sid, tt, 'reconnect'); }, delay);
        sendResponse({ ok: true }); break;
      }
      case 'beat': {
        // Liveness heartbeat from the page agent (and the answer to a probe).
        if (!genOk(req.sid, req.g)) { logRefusal(req.sid, staleText(req)); sendResponse({ ok: false }); break; }
        const t = searchTabs.get(req.sid);
        if (t) { t.lastBeatAt = Date.now(); t.recoverStreak = 0; t.injectFailStreak = 0; t.parkedLogged = false; }
        // 'connected' is otherwise said exactly once, at searchOpen. A host that missed it (it
        // (re)connected after the socket opened, or the open was refused by a bug like the one this
        // release fixes) would show "Linking…" for the life of the socket — so an open socket that
        // the host has not been told about is announced from its heartbeat.
        if (t && req.open === true && t.hostState !== 'connected' && ptbp && ptbp.connected) {
          t.hostState = 'connected';
          ptbp.sendSearchStatus(req.sid, 'connected');
          log(`Live search connected: ${String(req.sid).slice(0, 8)}… (announced from a heartbeat)`);
        }
        // A socket alive past the healthy threshold is PROOF the account is not penalized right
        // now — the only signal that may end a 1013 escalation (a calm timer fires mid-hold, and a
        // healthy socket may not CLOSE for hours, so the close path alone would never see it).
        if (t && req.open === true && t.lastOpenAt && Date.now() - t.lastOpenAt >= HEALTHY_OPEN_MS &&
            ((wsGate.streak1013 | 0) > 0 || wsGate.holdStreak > 0 || wsGate.fails.length)) {
          gateRecordHealthy(wsGate, Date.now()); saveGate();
        }
        sendResponse({ ok: true }); break;
      }
      case 'prepare': {
        if (!req.group || !ptbp || !hostBehavior.packetBatch || req.origin !== 'live' ||
            !genOk(req.sid, req.g) || busyHolder !== req.sid) {
          sendResponse({ ready: false, error: 'prepare_not_allowed' }); break;
        }
        try {
          const ready = await ptbp.prepareBuy(req.group, 'live');
          // The await crosses a host round trip.  Re-check ownership before giving the page
          // permission to whisper; a re-arm in that gap invalidates the old generation.
          if (!genOk(req.sid, req.g) || busyHolder !== req.sid) {
            ptbp.cancelPrepared(ready.id, 'agent_superseded');
            sendResponse({ ready: false, error: 'agent_superseded' }); break;
          }
          preparedOwners.set(ready.id, { sid: req.sid, g: req.g });
          sendResponse({ ready: true, prepareId: ready.id });
        } catch (e) {
          sendResponse({ ready: false, error: String((e && (e.code || e.message)) || 'prepare_failed') });
        }
        break;
      }
      case 'cancelPrepare': {
        const owner = preparedOwners.get(req.prepareId);
        if (owner && owner.sid === req.sid && owner.g === req.g) {
          preparedOwners.delete(req.prepareId);
          if (ptbp) ptbp.cancelPrepared(req.prepareId, req.reason || 'cancelled');
        }
        sendResponse({ ok: true }); break;
      }
      case 'buy': if (req.group && ptbp) {
        const prepareId = req.prepareId || '';
        if (prepareId) {
          const owner = preparedOwners.get(prepareId);
          if (!owner || owner.sid !== req.sid || owner.g !== req.g) {
            sendResponse({ ok: false, error: 'prepare_owner_mismatch' }); break;
          }
          preparedOwners.delete(prepareId);
        }
        const group = { ...req.group };
        const draft = group.timingDraft || req.timingDraft;
        delete group.timingDraft;
        if (draft) {
          const timing = finalizeTiming(draft);
          if (timing.stages.length) group.timing = timing;
        }
        const id = ptbp.sendBuyRequest(group, prepareId); log(`Sent buy ${id}`);
      } sendResponse({ ok: true }); break;
      // A superseded agent must never win the buy latch (that is how one listing becomes two
      // whispers). It stands down on its own; refusing the claim is the belt to that braces.
      case 'claim': {
        const current = genOk(req.sid, req.g);
        if (!current) logRefusal(req.sid, staleText(req));
        const grant = current && tryClaim(req.sid);
        sendResponse({ grant, reason: grant ? '' : (!current ? 'stale_agent' : (!hostReady ? 'host_not_ready' : 'latch_held')) });
        break;
      }
      case 'release': if (busyHolder === req.sid) clearBusy('agent'); sendResponse({ ok: true }); break;
      case 'tradeEvent': if (ptbp) {
        const ev = { stage: req.stage, outcome: req.outcome, itemId: req.itemId || '', detail: req.detail || '', item: req.item };
        if (req.timingDraft) {
          const timing = finalizeTiming(req.timingDraft);
          if (timing.stages.length) ev.timing = timing;
        }
        ptbp.sendTradeEvent(ev);
      } sendResponse({ ok: true }); break;
      case 'extlog': log(req.message); sendResponse({ ok: true }); break;
      case 'reload': await start(); sendResponse({ ok: true }); break;
      case 'mbprogress': if (manualBuy) { manualBuy.counts = { processed: req.processed|0, bought: req.bought|0, failed: req.failed|0, total: req.total|0 }; mbStatus('progress'); } sendResponse({ ok: true }); break;
      case 'mbdone': finishManualBuy(req.state || 'done', { processed: req.processed|0, bought: req.bought|0, failed: req.failed|0, total: req.total|0, detail: req.detail || '' }); sendResponse({ ok: true }); break;
      case 'getCh': {
        const doc = noteDocument(_s, req);      // synchronous bookkeeping FIRST (see noteDocument)
        sendResponse({ ch: await ensureCh() });
        if (doc) armIfComplete(doc.sid, doc.t);
        break;
      }
      default: sendResponse({ ok: false, error: 'unknown cmd' });
    }
  })().catch((e) => {
    // A rejected case must still answer, or the caller's sendMessage promise hangs forever.
    log(`onMessage ${req && req.cmd} failed: ${(e && e.message) || e}`);
    try { sendResponse({ ok: false, error: String((e && e.message) || e) }); } catch {}
  });
  return true; // async response
});

// The only durable timer a service worker has. It keeps the host connection up AND drives the
// live-search liveness sweep — the worker (and every setTimeout it holds) can be torn down at any
// moment, so nothing that must eventually happen may depend on a timer alone.
try {
  chrome.alarms.create('keepalive', { periodInMinutes: 0.4 });
  chrome.alarms.onAlarm.addListener(() => {
    if (ptbp && !ptbp.connected) ptbp.connect();
    sweepSearches().catch((e) => log(`Liveness sweep failed: ${(e && e.message) || e}`));
  });
} catch {}
start();

// Test-only exports: the MV3 module service worker ignores them; tests (tests/manualbuy-
// ratelimit.test.mjs, tests/liveagent-claim.test.mjs) call the MAIN-world bursts and the live
// agent directly to pin their rate-limit parsing and the claim/in-flight state machine.
export { pfxMbFetchPick, pfxMbWhisper, pfxLiveAgent };
