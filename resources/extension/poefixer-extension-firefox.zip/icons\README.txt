Place icon16.png (16x16), icon48.png (48x48), icon128.png (128x128) here.
Any simple PNG works; the extension loads without them but the browser shows a default icon.
