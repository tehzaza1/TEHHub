const send = (msg) => new Promise(res => chrome.runtime.sendMessage(msg, res));
const $ = (id) => document.getElementById(id);

async function refresh() {
  const st = await send({ cmd: 'getState' });
  if (!st) return;
  $('hostState').textContent = st.hostConnected ? 'connected' : 'disconnected';
  $('hostState').className = st.hostConnected ? 'ok' : 'bad';
  $('ready').textContent = st.ready ? 'yes' : 'no';
  $('ready').className = st.ready ? 'ok' : 'muted';
  if (document.activeElement !== $('port')) $('port').value = st.port;
}

$('savePort').onclick = async () => { await send({ cmd: 'setPort', port: parseInt($('port').value, 10) || 47362 }); refresh(); };

refresh(); setInterval(refresh, 2000);
